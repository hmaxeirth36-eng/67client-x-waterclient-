package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BeehiveBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * 67-style Chunk Finder: flags chunks with bee nests / full-honey beehives.
 */
public final class ChunkFinder extends Module {
   public static ChunkFinder INSTANCE;

   public final Setting<Integer> radius = new Setting<>("Radius", 6, 1, 16);
   public final Setting<Integer> mergeRadius = new Setting<>("Merge Radius", 2, 0, 8);
   public final Setting<Boolean> fullHoneyOnly = new Setting<>("Full Honey Only", false);
   public final Setting<Boolean> includeNest = new Setting<>("Bee Nest", true);
   public final Setting<Boolean> includeHive = new Setting<>("Beehive", true);
   public final Setting<Integer> displayY = new Setting<>("Display Y", 80, -64, 320);
   public final Setting<Integer> alpha = new Setting<>("Alpha", 60, 0, 255);
   public final Setting<Color> color = new Setting<>("Color", new Color(255, 200, 40, 60));

   public volatile Set<ChunkPos> hits = Collections.emptySet();
   private int tick;
   private int cursor;

   public ChunkFinder() {
      super("Chunk Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.radius);
      this.addSetting(this.mergeRadius);
      this.addSetting(this.fullHoneyOnly);
      this.addSetting(this.includeNest);
      this.addSetting(this.includeHive);
      this.addSetting(this.displayY);
      this.addSetting(this.alpha);
      this.addSetting(this.color);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptySet();
      this.cursor = 0;
   }

   @Override
   public void onDisable() {
      SusAlert.clear("CF");
      this.hits = Collections.emptySet();
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tick % 4 != 0) return;

      ChunkPos origin = mc.player.getChunkPos();
      int r = this.radius.getValue();
      List<ChunkPos> list = new ArrayList<>();
      for (int dx = -r; dx <= r; dx++) {
         for (int dz = -r; dz <= r; dz++) {
            list.add(new ChunkPos(origin.x + dx, origin.z + dz));
         }
      }
      if (list.isEmpty()) return;

      int perTick = 8;
      Set<ChunkPos> found = new HashSet<>();
      // keep previous in range
      for (ChunkPos cp : this.hits) {
         if (Math.abs(cp.x - origin.x) <= r && Math.abs(cp.z - origin.z) <= r) {
            found.add(cp);
         }
      }

      for (int n = 0; n < perTick; n++) {
         int idx = (this.cursor + n) % list.size();
         ChunkPos cp = list.get(idx);
         WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
         if (wc == null || wc.isEmpty()) {
            found.remove(cp);
            continue;
         }
         if (hasBeeSignal(wc)) found.add(cp);
         else found.remove(cp);
      }
      this.cursor = (this.cursor + perTick) % list.size();

      // optional merge: expand flagged neighbors
      int merge = this.mergeRadius.getValue();
      if (merge > 0 && !found.isEmpty()) {
         Set<ChunkPos> expanded = new HashSet<>(found);
         for (ChunkPos cp : found) {
            for (int dx = -merge; dx <= merge; dx++) {
               for (int dz = -merge; dz <= merge; dz++) {
                  if (dx * dx + dz * dz <= merge * merge) {
                     expanded.add(new ChunkPos(cp.x + dx, cp.z + dz));
                  }
               }
            }
         }
         // only keep expanded that are still near player
         expanded.removeIf(cp -> Math.abs(cp.x - origin.x) > r + merge || Math.abs(cp.z - origin.z) > r + merge);
         // merge display is soft: keep original hits for accuracy
         this.hits = Collections.unmodifiableSet(found);
            SusAlert.onNewHits("CF", this.hits, 0xFFFFC828);
      } else {
         this.hits = Collections.unmodifiableSet(found);
            SusAlert.onNewHits("CF", this.hits, 0xFFFFC828);
      }
   }

   private boolean hasBeeSignal(WorldChunk wc) {
      boolean nest = this.includeNest.getValue();
      boolean hive = this.includeHive.getValue();
      boolean fullOnly = this.fullHoneyOnly.getValue();

      // block entities first (accurate honey level)
      for (BlockEntity be : wc.getBlockEntities().values()) {
         if (be instanceof BeehiveBlockEntity hiveBe) {
            BlockState st = be.getCachedState();
            if (st.isOf(Blocks.BEE_NEST) && !nest) continue;
            if (st.isOf(Blocks.BEEHIVE) && !hive) continue;
            if (fullOnly) {
               if (st.contains(BeehiveBlock.HONEY_LEVEL) && st.get(BeehiveBlock.HONEY_LEVEL) >= 5) return true;
            } else {
               return true;
            }
         }
      }

      // section scan fallback
      for (ChunkSection sec : wc.getSectionArray()) {
         if (sec == null || sec.isEmpty()) continue;
         if (!sec.hasAny(st -> st.isOf(Blocks.BEE_NEST) || st.isOf(Blocks.BEEHIVE))) continue;
         for (int x = 0; x < 16; x++)
            for (int y = 0; y < 16; y++)
               for (int z = 0; z < 16; z++) {
                  BlockState st = sec.getBlockState(x, y, z);
                  if (st.isOf(Blocks.BEE_NEST) && nest) {
                     if (!fullOnly || (st.contains(BeehiveBlock.HONEY_LEVEL) && st.get(BeehiveBlock.HONEY_LEVEL) >= 5))
                        return true;
                  }
                  if (st.isOf(Blocks.BEEHIVE) && hive) {
                     if (!fullOnly || (st.contains(BeehiveBlock.HONEY_LEVEL) && st.get(BeehiveBlock.HONEY_LEVEL) >= 5))
                        return true;
                  }
               }
      }
      return false;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Set<ChunkPos> set = this.hits;
      if (set.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double y = this.displayY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color c = this.color.getValue();
      Color fill = new Color(c.getRed(), c.getGreen(), c.getBlue(), this.alpha.getValue());

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : set) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, fill);
         batch.renderOutlineBox(x1, y, z1, x1 + 16, y2, z1 + 16,
            new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.min(255, this.alpha.getValue() + 100)));
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }
}
