package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.ModeSetting;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Port of Anubis 0.9.9.3 Sus Chunk Finder:
 * - Method Classic / ANBS+
 * - GeodeGlow heat = glowCells / 12
 * - Spread radius heat to neighbours
 * - Detect mined (exposed budding/lining with low clusters)
 * - Light-5 bonus via ServerLightCache
 * Banner: AN
 */
public final class AnubisSusFinder extends Module {
   public static AnubisSusFinder INSTANCE;
   public static final int GLOW_CELLS_PER_POINT = 12;
   public static final int GEODE_Y_MIN = -56;
   public static final int GEODE_Y_MAX = 48;

   public final ModeSetting method = new ModeSetting("Method", "ANBS+", "Classic", "ANBS+");
   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> spreadRadius = new Setting<>("Spread Radius", 1, 0, 3);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 6, 1, 20);
   public final Setting<Integer> stableHits = new Setting<>("Stable Hits", 2, 1, 5);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 6, 2, 20);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 50, 0, 255);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(255, 120, 40, 50));
   public final Setting<Color> minedColor = new Setting<>("Mined Color", new Color(255, 40, 40, 70));
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Boolean> detectMined = new Setting<>("Detect Mined", true);
   public final Setting<Boolean> showPercent = new Setting<>("Show %", true);
   public final Setting<Boolean> showReason = new Setting<>("Show Reason", true);
   public final Setting<Boolean> useLight5 = new Setting<>("Use Light-5 Packets", true);
   public final Setting<Integer> minLight5 = new Setting<>("Min Light-5", 8, 1, 64);

   public static final class HitInfo {
      public final int heat;
      public final boolean mined;
      public final String reasons;
      public final int percent;
      public HitInfo(int heat, boolean mined, String reasons, int percent) {
         this.heat = heat;
         this.mined = mined;
         this.reasons = reasons;
         this.percent = percent;
      }
   }

   public volatile Map<ChunkPos, HitInfo> hits = Collections.emptyMap();
   private final Map<ChunkPos, Integer> streak = new ConcurrentHashMap<>();
   private final Map<ChunkPos, HitInfo> pending = new ConcurrentHashMap<>();
   private final Map<ChunkPos, Long> lastSeenMs = new ConcurrentHashMap<>();
   private final Map<ChunkPos, Integer> heatMap = new ConcurrentHashMap<>();

   public static final class LabelPos {
      public float x, y;
      public int percent;
      public String reasons = "";
      public boolean mined;
      public long lastOkMs;
   }

   public final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();
   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick, cursor;

   public AnubisSusFinder() {
      super("Anubis Sus Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.method);
      this.addSetting(this.simDist);
      this.addSetting(this.spreadRadius);
      this.addSetting(this.sensitivity);
      this.addSetting(this.stableHits);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.fillColor);
      this.addSetting(this.minedColor);
      this.addSetting(this.outline);
      this.addSetting(this.detectMined);
      this.addSetting(this.showPercent);
      this.addSetting(this.showReason);
      this.addSetting(this.useLight5);
      this.addSetting(this.minLight5);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.streak.clear();
      this.pending.clear();
      this.lastSeenMs.clear();
      this.heatMap.clear();
      this.labelCache.clear();
   }

   @Override
   public void onDisable() {
      SusAlert.clear("AN");
      this.hits = Collections.emptyMap();
      this.streak.clear();
      this.pending.clear();
      this.lastSeenMs.clear();
      this.heatMap.clear();
      this.labelCache.clear();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      ServerLightCache.INSTANCE.flushDirty(mc);
      if (++this.tick % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "anubis-sus");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simDist.getValue();
      final int spread = this.spreadRadius.getValue();
      final int sens = this.sensitivity.getValue();
      final int batch = this.scanSpeed.getValue();
      final int needStable = this.stableHits.getValue();
      final boolean anbs = this.method.is("ANBS+");
      final boolean mined = this.detectMined.getValue();
      final boolean doL5 = this.useLight5.getValue();
      final int minL5 = this.minLight5.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.cursor % positions.size();
      this.cursor = start + batch;
      final World world = mc.world;

      final Map<ChunkPos, Integer> lightSnap = new HashMap<>();
      if (doL5) {
         for (ChunkPos cp : positions) {
            int c = ServerLightCache.INSTANCE.getLight5Count(cp);
            if (c > 0) lightSnap.put(cp, c);
         }
      }

      this.exec.submit(() -> {
         try {
            Map<ChunkPos, Integer> localHeat = new HashMap<>();
            Map<ChunkPos, Boolean> localMined = new HashMap<>();
            Map<ChunkPos, List<String>> localReasons = new HashMap<>();

            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               GeodeResult gr = scanGeode(world, wc, cp, anbs);
               int heat = gr.heat;
               List<String> reasons = new ArrayList<>(gr.reasons);

               int l5 = lightSnap.getOrDefault(cp, 0);
               if (doL5 && l5 >= minL5) {
                  heat += Math.min(l5, 24) / 4;
                  if (!reasons.contains("L5")) reasons.add("L5");
               }

               if (heat > 0) {
                  localHeat.put(cp, heat);
                  localReasons.put(cp, reasons);
                  this.heatMap.put(cp, heat);
               } else {
                  this.heatMap.remove(cp);
               }

               if (mined && gr.exposed && gr.clusters == 0 && gr.budding >= 2) {
                  localMined.put(cp, true);
                  if (!reasons.contains("MINED")) reasons.add("MINED");
                  localReasons.put(cp, reasons);
               }
            }

            // Spread heat to neighbours (Anubis style)
            if (spread > 0) {
               Map<ChunkPos, Integer> extra = new HashMap<>();
               for (Map.Entry<ChunkPos, Integer> e : new HashMap<>(this.heatMap).entrySet()) {
                  int h = e.getValue();
                  if (h < sens) continue;
                  ChunkPos cp = e.getKey();
                  for (int dx = -spread; dx <= spread; dx++) {
                     for (int dz = -spread; dz <= spread; dz++) {
                        if (dx == 0 && dz == 0) continue;
                        ChunkPos n = new ChunkPos(cp.x + dx, cp.z + dz);
                        int share = Math.max(1, h / 3);
                        extra.merge(n, share, Math::max);
                     }
                  }
               }
               for (Map.Entry<ChunkPos, Integer> e : extra.entrySet()) {
                  this.heatMap.merge(e.getKey(), e.getValue(), Math::max);
               }
            }

            // Build hits for scanned batch using heatMap
            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               int heat = this.heatMap.getOrDefault(cp, 0);
               boolean isMined = localMined.getOrDefault(cp, false);
               List<String> reasons = localReasons.getOrDefault(cp, List.of());
               if (heat >= sens || isMined) {
                  float t = (heat - sens) / (float) Math.max(1, sens * 2);
                  if (t < 0f) t = 0f;
                  if (t > 1f) t = 1f;
                  int percent = Math.round((0.55f + 0.45f * t) * 100f);
                  if (isMined) percent = Math.max(percent, 80);
                  String rs = reasons.isEmpty() ? (anbs ? "ANBS" : "CL") : String.join("+", reasons);
                  HitInfo hi = new HitInfo(heat, isMined, rs, percent);
                  this.pending.put(cp, hi);
                  this.streak.merge(cp, 1, Integer::sum);
                  this.lastSeenMs.put(cp, System.currentTimeMillis());
               } else {
                  this.streak.remove(cp);
                  this.pending.remove(cp);
                  this.lastSeenMs.remove(cp);
               }
            }

            long nowMs = System.currentTimeMillis();
            this.streak.keySet().removeIf(cp -> {
               if (Math.abs(cp.x - origin.x) > radius || Math.abs(cp.z - origin.z) > radius) return true;
               Long seen = this.lastSeenMs.get(cp);
               return seen == null || nowMs - seen > 2500L;
            });
            this.pending.keySet().removeIf(cp -> !this.streak.containsKey(cp));
            this.lastSeenMs.keySet().removeIf(cp -> !this.streak.containsKey(cp));
            this.heatMap.keySet().removeIf(cp -> Math.abs(cp.x - origin.x) > radius + 1 || Math.abs(cp.z - origin.z) > radius + 1);

            Map<ChunkPos, HitInfo> published = new HashMap<>();
            for (Map.Entry<ChunkPos, Integer> e : this.streak.entrySet()) {
               if (e.getValue() >= needStable) {
                  HitInfo hi = this.pending.get(e.getKey());
                  if (hi != null) published.put(e.getKey(), hi);
               }
            }
            this.hits = Collections.unmodifiableMap(published);
            SusAlert.onNewHits("AN", this.hits, 0xFFFFAA44);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private static final class GeodeResult {
      int heat, clusters, budding, lining, glowCells;
      boolean exposed;
      final List<String> reasons = new ArrayList<>();
   }

   private static GeodeResult scanGeode(World world, WorldChunk chunk, ChunkPos cp, boolean anbs) {
      GeodeResult gr = new GeodeResult();
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;
         if (baseY > GEODE_Y_MAX || baseY + 15 < GEODE_Y_MIN) continue;
         if (!section.hasAny(AnubisSusFinder::isAmFamily)) continue;

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  int wy = baseY + ly;
                  if (wy < GEODE_Y_MIN || wy > GEODE_Y_MAX) continue;
                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();
                  int wx = x0 + lx, wz = z0 + lz;

                  boolean isAm = false;
                  if (b == Blocks.AMETHYST_BLOCK) { gr.lining++; isAm = true; }
                  else if (b == Blocks.BUDDING_AMETHYST) { gr.budding++; isAm = true; }
                  else if (b == Blocks.AMETHYST_CLUSTER) { gr.clusters++; isAm = true; }
                  else if (b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.SMALL_AMETHYST_BUD) {
                     isAm = true;
                  }
                  if (!isAm) continue;

                  // GeodeGlow: open neighbour with mid block light
                  for (Direction d : Direction.values()) {
                     mut.set(wx + d.getOffsetX(), wy + d.getOffsetY(), wz + d.getOffsetZ());
                     if (!world.isChunkLoaded(mut)) continue;
                     BlockState ns = world.getBlockState(mut);
                     if (!ns.isAir()) continue;
                     int light = world.getLightLevel(LightType.BLOCK, mut);
                     if (light >= 1 && light <= 10) {
                        gr.glowCells++;
                     }
                     // exposed to sky-ish air path above = mined candidate
                     if (d == Direction.UP && light >= 8) gr.exposed = true;
                  }
               }
            }
         }
      }

      // Classic: heat = glow/12
      gr.heat = gr.glowCells / GLOW_CELLS_PER_POINT;
      if (anbs) {
         // ANBS+: structure bonus + prefer grown clusters
         gr.heat += Math.min(gr.lining, 24) / 6;
         gr.heat += Math.min(gr.budding, 8);
         gr.heat += Math.min(gr.clusters, 10) * 2;
         if (gr.clusters >= 2) gr.reasons.add("CL");
         if (gr.glowCells >= GLOW_CELLS_PER_POINT) gr.reasons.add("GLOW");
         if (gr.lining + gr.budding >= 8) gr.reasons.add("AM");
      } else {
         if (gr.heat > 0) gr.reasons.add("GLOW");
         gr.heat += Math.min(gr.clusters, 6);
         if (gr.clusters > 0) gr.reasons.add("CL");
      }
      return gr;
   }

   private static boolean isAmFamily(BlockState st) {
      Block b = st.getBlock();
      return b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST
         || b == Blocks.AMETHYST_CLUSTER
         || b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.SMALL_AMETHYST_BUD;
   }

   private static boolean facingCamera(Vec3d camPos, float yawDeg, ChunkPos cp) {
      double cx = (cp.x << 4) + 8.0;
      double cz = (cp.z << 4) + 8.0;
      double dx = cx - camPos.x;
      double dz = cz - camPos.z;
      double len2 = dx * dx + dz * dz;
      if (len2 < 4.0) return true;
      double len = Math.sqrt(len2);
      double yaw = Math.toRadians(yawDeg);
      double lx = -Math.sin(yaw);
      double lz = Math.cos(yaw);
      return (dx / len) * lx + (dz / len) * lz > -0.15;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, HitInfo> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      Color mined = this.minedColor.getValue();
      int a = this.fillOpacity.getValue();
      float yaw = camera.getYaw();

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (Map.Entry<ChunkPos, HitInfo> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         if (!facingCamera(cam, yaw, cp)) continue;
         HitInfo hi = e.getValue();
         Color c = hi.mined ? mined : base;
         Color fill = new Color(c.getRed(), c.getGreen(), c.getBlue(), a);
         Color out = new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.min(255, a + 100));
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16, y2, z1 + 16, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      AnubisSusFinder self = INSTANCE;
      if (self == null || !self.isEnabled()) return;
      if (!self.showPercent.getValue() && !self.showReason.getValue()) return;
      Map<ChunkPos, HitInfo> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }
      double textY = self.renderY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();
      boolean showPct = self.showPercent.getValue();
      boolean showR = self.showReason.getValue();

      for (Map.Entry<ChunkPos, HitInfo> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         HitInfo hi = e.getValue();
         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.percent = hi.percent;
         lp.reasons = hi.reasons == null ? "" : hi.reasons;
         lp.mined = hi.mined;
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;
         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }
         if (now - lp.lastOkMs < 250L && lp.lastOkMs > 0) {
            String tag = lp.mined ? "AN*" : "AN";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            float ty = lp.y - 30f;
            int tagCol = lp.mined ? 0xFFFF4444 : 0xFFFFAA44;
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f, ty, tagCol);
            float lineY = ty + 10;
            if (showR && !lp.reasons.isEmpty()) {
               int rw = FontRenderer.INSTANCE.getWidth(lp.reasons);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f + 1, lineY + 1, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f, lineY, 0xFFFFE0A0);
               lineY += 10;
            }
            if (showPct) {
               String pct = lp.percent + "%";
               int pw = FontRenderer.INSTANCE.getWidth(pct);
               FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f + 1, lineY + 1, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f, lineY, 0xFFFFE0A0);
            }
         }
      }
      self.labelCache.keySet().removeIf(c -> !keep.contains(c));
   }
}
