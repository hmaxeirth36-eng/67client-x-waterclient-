package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PillarBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Krypton classic Sus — with stable hits + reason tags (KR banner).
 */
public final class KryptonSusFinder extends Module {
   public static KryptonSusFinder INSTANCE;

   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 3, 1, 30);
   public final Setting<Integer> stableHits = new Setting<>("Stable Hits", 2, 1, 5);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 8, 2, 24);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 50, 0, 255);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(180, 80, 255, 50));
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Boolean> showPercent = new Setting<>("Show %", true);
   public final Setting<Boolean> showReason = new Setting<>("Show Reason", true);

   public final Setting<Boolean> kelp = new Setting<>("Kelp", true);
   public final Setting<Boolean> caveVines = new Setting<>("Cave Vines", true);
   public final Setting<Boolean> vines = new Setting<>("Vines", false);
   public final Setting<Boolean> amethyst = new Setting<>("Amethyst", true);
   public final Setting<Boolean> bamboo = new Setting<>("Bamboo", true);
   public final Setting<Boolean> beeNest = new Setting<>("Bee Nest", true);
   public final Setting<Boolean> rotatedDeepslate = new Setting<>("Rotated Deepslate", true);
   public final Setting<Boolean> geodeGlow = new Setting<>("Geode Glow Bonus", false);

   public static final class HitInfo {
      public final int grown;
      public final String reasons;
      public final int percent;
      public HitInfo(int grown, String reasons, int percent) {
         this.grown = grown;
         this.reasons = reasons;
         this.percent = percent;
      }
   }

   public volatile Map<ChunkPos, HitInfo> hits = Collections.emptyMap();

   public static final class LabelPos {
      public float x, y;
      public int percent;
      public String reasons = "";
      public long lastOkMs;
   }

   private final Map<ChunkPos, Integer> streak = new ConcurrentHashMap<>();
   private final Map<ChunkPos, Long> lastSeenMs = new ConcurrentHashMap<>();
   private final Map<ChunkPos, HitInfo> pending = new ConcurrentHashMap<>();
   public final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick;
   private int cursor;

   public KryptonSusFinder() {
      super("Krypton Sus Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.stableHits);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.fillColor);
      this.addSetting(this.outline);
      this.addSetting(this.showPercent);
      this.addSetting(this.showReason);
      this.addSetting(this.kelp);
      this.addSetting(this.caveVines);
      this.addSetting(this.vines);
      this.addSetting(this.amethyst);
      this.addSetting(this.bamboo);
      this.addSetting(this.beeNest);
      this.addSetting(this.rotatedDeepslate);
      this.addSetting(this.geodeGlow);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.streak.clear();
      this.pending.clear();
      this.lastSeenMs.clear();
   }

   @Override
   public void onDisable() {
      SusAlert.clear("KR");
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.streak.clear();
      this.pending.clear();
      this.lastSeenMs.clear();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tick % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "krypton-classic-sus");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simDist.getValue();
      final int sens = this.sensitivity.getValue();
      final int batch = this.scanSpeed.getValue();
      final int needStable = this.stableHits.getValue();

      final boolean doKelp = this.kelp.getValue();
      final boolean doCave = this.caveVines.getValue();
      final boolean doVines = this.vines.getValue();
      final boolean doAm = this.amethyst.getValue();
      final boolean doBamboo = this.bamboo.getValue();
      final boolean doBee = this.beeNest.getValue();
      final boolean doRot = this.rotatedDeepslate.getValue();
      final boolean doGlow = this.geodeGlow.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.cursor % positions.size();
      this.cursor = start + batch;
      final World world = mc.world;

      this.exec.submit(() -> {
         try {
            Map<ChunkPos, HitInfo> batchHits = new HashMap<>();
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               CountResult cr = countGrown(world, wc, cp, doKelp, doCave, doVines, doAm, doBamboo, doBee, doRot, doGlow);
               if (cr.count >= sens && !cr.reasons.isEmpty()) {
                  float t = (cr.count - sens) / (float) Math.max(1, sens * 2);
                  if (t < 0f) t = 0f;
                  if (t > 1f) t = 1f;
                  int percent = Math.round((0.55f + 0.45f * t) * 100f);
                  batchHits.put(cp, new HitInfo(cr.count, String.join("+", cr.reasons), percent));
               }
            }

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               HitInfo hi = batchHits.get(cp);
               if (hi != null) {
                  this.pending.put(cp, hi);
                  this.streak.merge(cp, 1, Integer::sum);
                  this.lastSeenMs.put(cp, System.currentTimeMillis());
               } else {
                  this.streak.remove(cp);
                  this.pending.remove(cp);
                  this.lastSeenMs.remove(cp);
               }
            }

            Map<ChunkPos, HitInfo> published = new HashMap<>();
            for (Map.Entry<ChunkPos, Integer> e : this.streak.entrySet()) {
               if (e.getValue() >= needStable) {
                  HitInfo hi = this.pending.get(e.getKey());
                  if (hi != null) published.put(e.getKey(), hi);
               }
            }
            long nowMs = System.currentTimeMillis();
            this.streak.keySet().removeIf(cp -> {
               if (Math.abs(cp.x - origin.x) > radius || Math.abs(cp.z - origin.z) > radius) return true;
               Long seen = this.lastSeenMs.get(cp);
               return seen == null || nowMs - seen > 2500L;
            });
            this.lastSeenMs.keySet().removeIf(cp -> !this.streak.containsKey(cp));
            this.pending.keySet().removeIf(cp -> !this.streak.containsKey(cp));
            this.hits = Collections.unmodifiableMap(published);
            SusAlert.onNewHits("KR", this.hits, 0xFFCC66FF);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private static final class CountResult {
      int count;
      final List<String> reasons = new ArrayList<>();
      void add(String r, int n) {
         if (n <= 0) return;
         this.count += n;
         if (!this.reasons.contains(r)) this.reasons.add(r);
      }
   }

   private static CountResult countGrown(
         World world, WorldChunk chunk, ChunkPos cp,
         boolean doKelp, boolean doCave, boolean doVines, boolean doAm,
         boolean doBamboo, boolean doBee, boolean doRot, boolean doGlow
   ) {
      CountResult cr = new CountResult();
      int glowCells = 0;
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();
                  int wx = x0 + lx, wy = baseY + ly, wz = z0 + lz;

                  if (doKelp && (b == Blocks.KELP || b == Blocks.KELP_PLANT)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.KELP) || above.isOf(Blocks.KELP_PLANT)) continue;
                     int age = st.contains(Properties.AGE_25) ? st.get(Properties.AGE_25) : 0;
                     if ((b == Blocks.KELP && age >= 20) || columnLen(world, wx, wy, wz, Direction.DOWN, Blocks.KELP, Blocks.KELP_PLANT) >= 8) {
                        cr.add("KELP", 1);
                     }
                     continue;
                  }
                  if (doCave && (b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT)) {
                     mut.set(wx, wy - 1, wz);
                     BlockState below = world.getBlockState(mut);
                     if (below.isOf(Blocks.CAVE_VINES) || below.isOf(Blocks.CAVE_VINES_PLANT)) continue;
                     boolean berries = st.contains(Properties.BERRIES) && st.get(Properties.BERRIES);
                     if (berries || columnLen(world, wx, wy, wz, Direction.UP, Blocks.CAVE_VINES, Blocks.CAVE_VINES_PLANT) >= 6) {
                        cr.add("CAVE", 1);
                     }
                     continue;
                  }
                  if (doVines && b == Blocks.VINE) {
                     if (((wx + wy + wz) & 7) == 0) cr.add("VIN", 1);
                     continue;
                  }
                  if (doAm) {
                     if (b == Blocks.AMETHYST_CLUSTER) {
                        cr.add("AM", 2);
                        if (doGlow) glowCells += glowAround(world, wx, wy, wz, mut);
                        continue;
                     }
                     if (b == Blocks.LARGE_AMETHYST_BUD) {
                        cr.add("AM", 1);
                        continue;
                     }
                     if (b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST) {
                        if (((wx + wy + wz) & 15) == 0) cr.add("AM", 1);
                        if (doGlow) glowCells += glowAround(world, wx, wy, wz, mut);
                        continue;
                     }
                  }
                  if (doBamboo && (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.BAMBOO) || above.isOf(Blocks.BAMBOO_SAPLING)) continue;
                     if (columnLen(world, wx, wy, wz, Direction.DOWN, Blocks.BAMBOO, Blocks.BAMBOO_SAPLING) >= 10) {
                        cr.add("BAM", 1);
                     }
                     continue;
                  }
                  if (doBee && (b == Blocks.BEE_NEST || b == Blocks.BEEHIVE)) {
                     cr.add("BEE", 2);
                     continue;
                  }
                  if (doRot && isRotatedDeepslate(st)) {
                     cr.add("ROT", 1);
                  }
               }
            }
         }
      }
      if (doGlow && glowCells >= 12) {
         cr.add("GLOW", glowCells / 12);
      }
      return cr;
   }

   private static int glowAround(World world, int x, int y, int z, BlockPos.Mutable mut) {
      int n = 0;
      for (Direction d : Direction.values()) {
         mut.set(x + d.getOffsetX(), y + d.getOffsetY(), z + d.getOffsetZ());
         if (!world.isChunkLoaded(mut)) continue;
         if (!world.getBlockState(mut).isAir()) continue;
         int light = world.getLightLevel(LightType.BLOCK, mut);
         if (light >= 1 && light <= 10) n++;
      }
      return n;
   }

   private static int columnLen(World world, int x, int y, int z, Direction dir, Block... match) {
      BlockPos.Mutable mut = new BlockPos.Mutable(x, y, z);
      int n = 0;
      for (int i = 0; i < 32; i++) {
         BlockState st = world.getBlockState(mut);
         boolean ok = false;
         for (Block b : match) {
            if (st.isOf(b)) { ok = true; break; }
         }
         if (!ok) break;
         n++;
         mut.move(dir);
      }
      return n;
   }

   private static boolean isRotatedDeepslate(BlockState st) {
      Block b = st.getBlock();
      if (b != Blocks.DEEPSLATE && b != Blocks.COBBLED_DEEPSLATE
            && b != Blocks.POLISHED_DEEPSLATE && b != Blocks.DEEPSLATE_BRICKS
            && b != Blocks.DEEPSLATE_TILES) {
         return false;
      }
      if (st.contains(Properties.AXIS)) {
         return st.get(Properties.AXIS) != Direction.Axis.Y;
      }
      if (st.contains(PillarBlock.AXIS)) {
         return st.get(PillarBlock.AXIS) != Direction.Axis.Y;
      }
      return false;
   }


   /** Only draw chunks roughly in front of the camera (cuts lag + stale rear flags). */
   private static boolean facingCamera(Vec3d camPos, float yawDeg, ChunkPos cp) {
      double cx = (cp.x << 4) + 8.0;
      double cz = (cp.z << 4) + 8.0;
      double dx = cx - camPos.x;
      double dz = cz - camPos.z;
      double len2 = dx * dx + dz * dz;
      if (len2 < 4.0) return true; // always show under feet
      double len = Math.sqrt(len2);
      double yaw = Math.toRadians(yawDeg);
      // camera look on XZ: -sin(yaw), cos(yaw) in MC
      double lx = -Math.sin(yaw);
      double lz = Math.cos(yaw);
      double dot = (dx / len) * lx + (dz / len) * lz;
      return dot > -0.15; // slight behind still ok, full rear culled
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, HitInfo> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 100));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      float yaw = camera.getYaw();
      for (ChunkPos cp : map.keySet()) {
         if (!facingCamera(cam, yaw, cp)) continue;
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16, y2, z1 + 16, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      KryptonSusFinder self = INSTANCE;
      if (self == null || !self.isEnabled()) return;
      if (!self.showPercent.getValue() && !self.showReason.getValue()) return;
      Map<ChunkPos, HitInfo> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }
      double textY = self.renderY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();
      boolean showPct = self.showPercent.getValue();
      boolean showR = self.showReason.getValue();

      for (Map.Entry<ChunkPos, HitInfo> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         HitInfo hi = e.getValue();
         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.percent = hi.percent;
         lp.reasons = hi.reasons == null ? "" : hi.reasons;
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;
         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }
         if (now - lp.lastOkMs < 250L && lp.lastOkMs > 0) {
            String tag = "KR";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            float ty = lp.y - 18f;
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f, ty, 0xFFCC66FF);
            float lineY = ty + 10;
            if (showR && !lp.reasons.isEmpty()) {
               int rw = FontRenderer.INSTANCE.getWidth(lp.reasons);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f + 1, lineY + 1, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f, lineY, 0xFFE8CCFF);
               lineY += 10;
            }
            if (showPct) {
               String pct = lp.percent + "%";
               int pw = FontRenderer.INSTANCE.getWidth(pct);
               FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f + 1, lineY + 1, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f, lineY, 0xFFE8CCFF);
            }
         }
      }
      self.labelCache.keySet().removeIf(c -> !keep.contains(c));
   }
}
