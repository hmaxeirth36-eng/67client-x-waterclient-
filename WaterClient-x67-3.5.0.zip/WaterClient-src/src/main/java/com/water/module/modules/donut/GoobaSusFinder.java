package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Gooba-style Sus Chunk Finder (from gooba-buildable-source):
 * - Find amethyst geode structure (lining/budding)
 * - Detect "missing clusters": air/cavity cells near amethyst with block-light ~4-5
 * - Large missing-cluster groups + few visible clusters = player activity / dug geode
 * Banner: GB
 */
public final class GoobaSusFinder extends Module {
   public static GoobaSusFinder INSTANCE;

   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 4, 1, 20);
   public final Setting<Integer> minStructure = new Setting<>("Min Structure Blocks", 5, 3, 30);
   public final Setting<Integer> minMissing = new Setting<>("Min Missing Cluster", 6, 3, 40);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 6, 2, 20);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 50, 0, 255);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(255, 80, 160, 50));
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Boolean> showLabel = new Setting<>("Show Label", true);
   public final Setting<Boolean> useLight5 = new Setting<>("Use Light-5 Packets", true);

   public static final class HitInfo {
      public final int missing;
      public final int structure;
      public final int clusters;
      public final String reasons;
      public HitInfo(int missing, int structure, int clusters, String reasons) {
         this.missing = missing;
         this.structure = structure;
         this.clusters = clusters;
         this.reasons = reasons;
      }
   }

   public volatile Map<ChunkPos, HitInfo> hits = Collections.emptyMap();
   private final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   public static final class LabelPos {
      public float x, y;
      public String reasons = "";
      public long lastOkMs;
   }

   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick, cursor;

   public GoobaSusFinder() {
      super("Gooba Sus Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.minStructure);
      this.addSetting(this.minMissing);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.fillColor);
      this.addSetting(this.outline);
      this.addSetting(this.showLabel);
      this.addSetting(this.useLight5);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
   }

   @Override
   public void onDisable() {
      SusAlert.clear("GB");
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      ServerLightCache.INSTANCE.flushDirty(mc);
      if (++this.tick % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "gooba-sus");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simDist.getValue();
      final int sens = this.sensitivity.getValue();
      final int batch = this.scanSpeed.getValue();
      final int minStruct = this.minStructure.getValue();
      final int minMiss = this.minMissing.getValue();
      final boolean doL5 = this.useLight5.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.cursor % positions.size();
      this.cursor = start + batch;
      final World world = mc.world;

      final Map<ChunkPos, HitInfo> retained = new HashMap<>();
      for (Map.Entry<ChunkPos, HitInfo> e : this.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         if (Math.abs(cp.x - origin.x) <= radius && Math.abs(cp.z - origin.z) <= radius) {
            retained.put(cp, e.getValue());
         }
      }

      this.exec.submit(() -> {
         try {
            Map<ChunkPos, HitInfo> next = new HashMap<>(retained);
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               ScanResult sr = scan(world, wc, cp, minStruct, doL5);

               // threshold: missing cluster size vs sensitivity
               int need = Math.max(minMiss, sens * 2);
               boolean flag = sr.structure >= minStruct && (sr.missing >= need || (sr.missing >= minMiss && sr.clusters <= 1));

               // light-5 support (Donut)
               if (!flag && doL5) {
                  int l5 = ServerLightCache.INSTANCE.getLight5Count(cp);
                  if (l5 >= 8 && sr.structure >= 3) {
                     flag = true;
                     sr.reasons.add("L5");
                  }
               }

               if (flag) {
                  if (sr.missing > 0 && !sr.reasons.contains("MISS")) sr.reasons.add("MISS");
                  if (sr.structure > 0 && !sr.reasons.contains("AM")) sr.reasons.add("AM");
                  next.put(cp, new HitInfo(sr.missing, sr.structure, sr.clusters, String.join("+", sr.reasons)));
               } else {
                  next.remove(cp);
               }
            }
            this.hits = Collections.unmodifiableMap(next);
            SusAlert.onNewHits("GB", this.hits, 0xFFFF66AA);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private static final class ScanResult {
      int structure, clusters, missing;
      final List<String> reasons = new ArrayList<>();
   }

   private static ScanResult scan(World world, WorldChunk chunk, ChunkPos cp, int minStruct, boolean doL5) {
      ScanResult sr = new ScanResult();
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      List<BlockPos> cavity = new ArrayList<>();
      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;
         if (baseY > 48 || baseY + 15 < -56) continue;

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  int wy = baseY + ly;
                  if (wy < -56 || wy > 48) continue;
                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();
                  int wx = x0 + lx, wz = z0 + lz;

                  if (b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST) {
                     sr.structure++;
                     // cavity neighbours with mid light = missing-cluster candidates
                     for (Direction d : Direction.values()) {
                        mut.set(wx + d.getOffsetX(), wy + d.getOffsetY(), wz + d.getOffsetZ());
                        if (!world.isChunkLoaded(mut)) continue;
                        BlockState ns = world.getBlockState(mut);
                        if (!(ns.isAir() || ns.isOf(Blocks.AMETHYST_CLUSTER))) continue;
                        int light = world.getLightLevel(LightType.BLOCK, mut);
                        // Gooba uses light boundary around 4
                        if (light >= 3 && light <= 6) {
                           cavity.add(mut.toImmutable());
                        }
                     }
                  } else if (b == Blocks.AMETHYST_CLUSTER) {
                     sr.clusters++;
                  } else if (b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD) {
                     // still structure activity
                  }
               }
            }
         }
      }

      // Cluster cavity points within distance 6 (like Gooba clique approx)
      sr.missing = largestCavityGroup(cavity);
      return sr;
   }

   private static int largestCavityGroup(List<BlockPos> cells) {
      if (cells.isEmpty()) return 0;
      boolean[] used = new boolean[cells.size()];
      int best = 0;
      for (int i = 0; i < cells.size(); i++) {
         if (used[i]) continue;
         int count = 0;
         ArrayList<Integer> q = new ArrayList<>();
         q.add(i);
         used[i] = true;
         while (!q.isEmpty()) {
            int idx = q.remove(q.size() - 1);
            count++;
            BlockPos a = cells.get(idx);
            for (int j = 0; j < cells.size(); j++) {
               if (used[j]) continue;
               if (a.getSquaredDistance(cells.get(j)) <= 36.0) {
                  used[j] = true;
                  q.add(j);
               }
            }
         }
         if (count > best) best = count;
      }
      return best;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, HitInfo> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 100));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : map.keySet()) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16, y2, z1 + 16, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      GoobaSusFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showLabel.getValue()) return;
      Map<ChunkPos, HitInfo> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }
      double textY = self.renderY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();
      for (Map.Entry<ChunkPos, HitInfo> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.reasons = e.getValue().reasons;
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;
         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }
         if (now - lp.lastOkMs < 250L && lp.lastOkMs > 0) {
            String tag = "GB";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            float ty = lp.y - 42f;
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, lp.x - tw / 2f, ty, 0xFFFF66AA);
            if (lp.reasons != null && !lp.reasons.isEmpty()) {
               int rw = FontRenderer.INSTANCE.getWidth(lp.reasons);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f + 1, ty + 11, 0xFF000000);
               FontRenderer.INSTANCE.drawString(context, lp.reasons, lp.x - rw / 2f, ty + 10, 0xFFFFCCDD);
            }
         }
      }
      self.labelCache.keySet().removeIf(c -> !keep.contains(c));
   }
}
