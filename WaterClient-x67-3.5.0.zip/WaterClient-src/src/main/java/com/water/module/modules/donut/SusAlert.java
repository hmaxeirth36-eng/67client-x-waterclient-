package com.water.module.modules.donut;

import com.water.gui.NotificationManager;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.ChunkPos;

/**
 * Shared alert when any Sus / Chunk Finder newly flags a chunk.
 * Kryptic/Platinum ships no custom .ogg — notifications there are visual;
 * we approximate the "ping" with a clear vanilla UI/orb sound + toast.
 */
public final class SusAlert {
   private static final Map<String, Set<Long>> ALERTED = new ConcurrentHashMap<>();
   private static final Map<String, Long> LAST_SOUND_MS = new ConcurrentHashMap<>();
   private static final long SOUND_COOLDOWN_MS = 400L;
   private static final long FORGET_OUTSIDE_MS = 30_000L;

   private SusAlert() {}

   public static void onNewHits(String source, Collection<ChunkPos> currentHits, int accentArgb) {
      if (source == null || currentHits == null) return;
      Set<Long> prev = ALERTED.computeIfAbsent(source, k -> ConcurrentHashMap.newKeySet());
      Set<Long> now = new HashSet<>();
      for (ChunkPos cp : currentHits) {
         if (cp != null) now.add(ChunkPos.toLong(cp.x, cp.z));
      }

      Set<Long> fresh = new HashSet<>(now);
      fresh.removeAll(prev);
      prev.clear();
      prev.addAll(now);

      if (fresh.isEmpty()) return;

      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.player == null) return;

      // one sound burst per wave (not per chunk)
      long t = System.currentTimeMillis();
      Long last = LAST_SOUND_MS.get(source);
      if (last == null || t - last >= SOUND_COOLDOWN_MS) {
         LAST_SOUND_MS.put(source, t);
         // Distinct pitch per source so multi-finder is recognizable
         float pitch = pitchFor(source);
         mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.9F, pitch);
         // soft follow-up (same family as other Water notifiers)
         final float p2 = Math.min(2.0F, pitch + 0.2F);
         mc.execute(() -> {
            if (mc.player != null) {
               mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.45F, p2);
            }
         });
      }

      // toast for first few new chunks
      int n = 0;
      for (long key : fresh) {
         if (n >= 3) break;
         int cx = ChunkPos.getPackedX(key);
         int cz = ChunkPos.getPackedZ(key);
         NotificationManager.INSTANCE.push(
            source,
            "Chunk " + cx + ", " + cz,
            new ItemStack(Items.AMETHYST_SHARD),
            accentArgb
         );
         n++;
      }
      if (fresh.size() > 3) {
         NotificationManager.INSTANCE.push(
            source,
            "+" + (fresh.size() - 3) + " more chunks",
            new ItemStack(Items.AMETHYST_CLUSTER),
            accentArgb
         );
      }
   }

   public static void onNewHits(String source, Map<ChunkPos, ?> hits, int accentArgb) {
      if (hits == null) {
         onNewHits(source, Set.of(), accentArgb);
         return;
      }
      onNewHits(source, hits.keySet(), accentArgb);
   }

   public static void clear(String source) {
      if (source == null) return;
      ALERTED.remove(source);
      LAST_SOUND_MS.remove(source);
   }

   private static float pitchFor(String source) {
      if (source == null) return 1.0F;
      return switch (source) {
         case "67" -> 1.15F;
         case "KR" -> 0.95F;
         case "AN" -> 1.05F;
         case "GB" -> 1.25F;
         case "AS" -> 1.35F;
         case "PR" -> 0.85F;
         case "CF" -> 1.0F;
         default -> 1.1F;
      };
   }
}
