package com.water.module.modules.misc;

import com.water.gui.NotificationManager;
import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/**
 * Warn when horizontal speed is too high (run / fly / elytra).
 * Inspired by movement speed HUDs in Krypton-style clients (kb/s display);
 * this module adds explicit overspeed alerts.
 */
public final class SpeedAlert extends Module {
   public static SpeedAlert INSTANCE;

   public final Setting<Boolean> warnRun = new Setting<>("Warn Running", true);
   public final Setting<Double> runLimit = new Setting<>("Run Limit b/s", 8.0, 4.0, 30.0);
   public final Setting<Boolean> warnFly = new Setting<>("Warn Flying", true);
   public final Setting<Double> flyLimit = new Setting<>("Fly Limit b/s", 25.0, 8.0, 80.0);
   public final Setting<Boolean> warnElytra = new Setting<>("Warn Elytra", true);
   public final Setting<Double> elytraLimit = new Setting<>("Elytra Limit b/s", 45.0, 15.0, 120.0);
   public final Setting<Integer> sustainTicks = new Setting<>("Sustain Ticks", 8, 2, 40);
   public final Setting<Boolean> sound = new Setting<>("Sound", true);
   public final Setting<Boolean> toast = new Setting<>("Toast", true);
   public final Setting<Integer> cooldownSec = new Setting<>("Cooldown Sec", 3, 1, 15);

   private int overTicks;
   private long lastAlertMs;
   private double lastBps;

   public SpeedAlert() {
      super("Speed Alert", Category.MISC);
      INSTANCE = this;
      this.addSetting(this.warnRun);
      this.addSetting(this.runLimit);
      this.addSetting(this.warnFly);
      this.addSetting(this.flyLimit);
      this.addSetting(this.warnElytra);
      this.addSetting(this.elytraLimit);
      this.addSetting(this.sustainTicks);
      this.addSetting(this.sound);
      this.addSetting(this.toast);
      this.addSetting(this.cooldownSec);
   }

   @Override
   public void onEnable() {
      this.overTicks = 0;
      this.lastAlertMs = 0L;
   }

   @Override
   public void onTick() {
      if (mc.player == null || mc.world == null) return;

      Vec3d v = mc.player.getVelocity();
      // horizontal blocks per tick → * 20 = b/s
      double bps = Math.sqrt(v.x * v.x + v.z * v.z) * 20.0;
      this.lastBps = bps;

      String mode = null;
      double limit = Double.MAX_VALUE;

      boolean elytra = mc.player.isGliding();
      boolean flying = mc.player.getAbilities().flying || (!mc.player.isOnGround() && !elytra && Math.abs(v.y) > 0.05 && bps > 6.0);
      // treat creative/spectator flight
      if (mc.player.getAbilities().flying) flying = true;

      if (elytra && this.warnElytra.getValue()) {
         mode = "Elytra";
         limit = this.elytraLimit.getValue();
      } else if (flying && this.warnFly.getValue()) {
         mode = "Fly";
         limit = this.flyLimit.getValue();
      } else if (mc.player.isOnGround() && this.warnRun.getValue()) {
         mode = mc.player.isSprinting() ? "Sprint" : "Run";
         limit = this.runLimit.getValue();
      }

      if (mode == null || bps < limit) {
         this.overTicks = 0;
         return;
      }

      this.overTicks++;
      if (this.overTicks < this.sustainTicks.getValue()) return;

      long now = System.currentTimeMillis();
      long cd = this.cooldownSec.getValue() * 1000L;
      if (now - this.lastAlertMs < cd) return;
      this.lastAlertMs = now;
      this.overTicks = 0;

      String msg = String.format("%s too fast · %.1f b/s (limit %.1f)", mode, bps, limit);
      if (this.sound.getValue()) {
         mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.85F, 0.55F);
         mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5F, 0.75F);
      }
      if (this.toast.getValue()) {
         NotificationManager.INSTANCE.push(
            "Speed Alert",
            msg,
            new ItemStack(Items.FEATHER),
            0xFFFFAA33
         );
      }
   }

   public double getLastBps() {
      return this.lastBps;
   }
}
