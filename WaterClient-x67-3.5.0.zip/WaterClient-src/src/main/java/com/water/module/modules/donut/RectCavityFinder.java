package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Rect Cavity Finder — marks rectangular room-like air pockets.
 * Does NOT rely on chest/storage ESP (works when containers are hidden until close).
 * Sticky hits survive chunk unload for navigation when deep layers go dark.
 */
public final class RectCavityFinder extends Module {
   public static RectCavityFinder INSTANCE;

   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 4, 1, 8);
   public final Setting<Integer> minSize = new Setting<>("Min Size", 5, 3, 16);
   public final Setting<Integer> maxSize = new Setting<>("Max Size", 28, 8, 48);
   public final Setting<Integer> minHeight = new Setting<>("Min Height", 3, 2, 12);
   public final Setting<Integer> maxHeight = new Setting<>("Max Height", 12, 4, 32);
   public final Setting<Integer> minY = new Setting<>("Min Y", -60, -64, 100);
   public final Setting<Integer> maxY = new Setting<>("Max Y", 40, -20, 200);
   public final Setting<Integer> minScore = new Setting<>("Min Score", 12, 4, 40);
   public final Setting<Integer> scanStep = new Setting<>("Scan Step", 2, 1, 4);
   public final Setting<Boolean> requireFloor = new Setting<>("Require Floor", true);
   public final Setting<Boolean> requireCeiling = new Setting<>("Require Ceiling", true);
   public final Setting<Boolean> lightAssist = new Setting<>("Light Assist", true);
   public final Setting<Boolean> sticky = new Setting<>("Sticky Hits", true);
   public final Setting<Integer> stickySeconds = new Setting<>("Sticky Seconds", 180, 30, 600);
   public final Setting<Integer> alpha = new Setting<>("Alpha", 120, 30, 255);
   public final Setting<Color> color = new Setting<>("Box Color", new Color(255, 140, 40, 120));

   public static final class Hit {
      public final int minX, minY, minZ, maxX, maxY, maxZ;
      public final int score;
      public final long createdMs;
      public volatile long lastSeenMs;

      public Hit(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, int score, long now) {
         this.minX = minX;
         this.minY = minY;
         this.minZ = minZ;
         this.maxX = maxX;
         this.maxY = maxY;
         this.maxZ = maxZ;
         this.score = score;
         this.createdMs = now;
         this.lastSeenMs = now;
      }

      public long key() {
         // quantize center to reduce duplicates
         int cx = (minX + maxX) >> 1;
         int cy = (minY + maxY) >> 1;
         int cz = (minZ + maxZ) >> 1;
         return (((long) (cx >> 2)) & 0x3fffffL) << 42
            | (((long) (cz >> 2)) & 0x3fffffL) << 20
            | (((long) (cy >> 2)) & 0xfffffL);
      }
   }

   public volatile List<Hit> hits = List.of();
   private final Map<Long, Hit> stickyMap = new ConcurrentHashMap<>();
   private int tickCounter;
   private int scanCursor;

   public RectCavityFinder() {
      super("Rect Cavity", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simDist);
      this.addSetting(this.minSize);
      this.addSetting(this.maxSize);
      this.addSetting(this.minHeight);
      this.addSetting(this.maxHeight);
      this.addSetting(this.minY);
      this.addSetting(this.maxY);
      this.addSetting(this.minScore);
      this.addSetting(this.scanStep);
      this.addSetting(this.requireFloor);
      this.addSetting(this.requireCeiling);
      this.addSetting(this.lightAssist);
      this.addSetting(this.sticky);
      this.addSetting(this.stickySeconds);
      this.addSetting(this.alpha);
      this.addSetting(this.color);
   }

   @Override
   public void onEnable() {
      this.hits = List.of();
      this.scanCursor = 0;
   }

   @Override
   public void onDisable() {
      this.hits = List.of();
      if (!this.sticky.getValue()) {
         this.stickyMap.clear();
      }
   }

   @Override
   public void onTick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null || mc.player == null) {
         return;
      }
      this.tickCounter++;
      if ((this.tickCounter & 1) != 0) {
         return; // every other tick
      }

      World world = mc.world;
      ChunkPos playerChunk = mc.player.getChunkPos();
      int radius = this.simDist.getValue();
      int step = Math.max(1, this.scanStep.getValue());
      int y0 = this.minY.getValue();
      int y1 = this.maxY.getValue();
      int minS = this.minSize.getValue();
      int maxS = this.maxSize.getValue();
      int minH = this.minHeight.getValue();
      int maxH = this.maxHeight.getValue();
      int need = this.minScore.getValue();
      boolean needFloor = this.requireFloor.getValue();
      boolean needCeil = this.requireCeiling.getValue();
      boolean useLight = this.lightAssist.getValue();
      long now = System.currentTimeMillis();

      List<ChunkPos> order = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            order.add(new ChunkPos(playerChunk.x + dx, playerChunk.z + dz));
         }
      }
      if (order.isEmpty()) {
         return;
      }
      this.scanCursor = this.scanCursor % order.size();
      int budget = Math.min(6, order.size());
      Map<Long, Hit> batch = new HashMap<>();

      for (int b = 0; b < budget; b++) {
         ChunkPos cp = order.get((this.scanCursor + b) % order.size());
         WorldChunk chunk = world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
         if (chunk == null) {
            continue;
         }
         int baseX = cp.getStartX();
         int baseZ = cp.getStartZ();
         for (int ly = y0; ly <= y1; ly += step) {
            for (int lx = 0; lx < 16; lx += step) {
               for (int lz = 0; lz < 16; lz += step) {
                  int x = baseX + lx;
                  int z = baseZ + lz;
                  if (!isAirOpen(world, x, ly, z)) {
                     continue;
                  }
                  Hit hit = measureRoom(world, x, ly, z, minS, maxS, minH, maxH, needFloor, needCeil, useLight, need, now);
                  if (hit == null) {
                     continue;
                  }
                  long key = hit.key();
                  Hit prev = batch.get(key);
                  if (prev == null || hit.score > prev.score) {
                     batch.put(key, hit);
                  }
               }
            }
         }
      }
      this.scanCursor = (this.scanCursor + budget) % Math.max(1, order.size());

      // merge sticky
      if (this.sticky.getValue()) {
         long ttl = this.stickySeconds.getValue() * 1000L;
         for (Hit h : batch.values()) {
            Hit old = this.stickyMap.get(h.key());
            if (old == null || h.score >= old.score) {
               this.stickyMap.put(h.key(), h);
            } else {
               old.lastSeenMs = now;
            }
         }
         Iterator<Map.Entry<Long, Hit>> it = this.stickyMap.entrySet().iterator();
         while (it.hasNext()) {
            Map.Entry<Long, Hit> e = it.next();
            if (now - e.getValue().lastSeenMs > ttl && now - e.getValue().createdMs > ttl) {
               it.remove();
            }
         }
         // refresh lastSeen for still-visible
         for (Hit h : batch.values()) {
            Hit s = this.stickyMap.get(h.key());
            if (s != null) {
               s.lastSeenMs = now;
            }
         }
         this.hits = List.copyOf(this.stickyMap.values());
      } else {
         this.stickyMap.clear();
         this.hits = List.copyOf(batch.values());
      }
   }

   private static boolean isAirOpen(World world, int x, int y, int z) {
      BlockState st = world.getBlockState(new BlockPos(x, y, z));
      if (st.isAir()) return true;
      // leaves / berries / etc. — treat as not room air for expansion
      return false;
   }

   private static boolean isSolidWall(World world, int x, int y, int z) {
      BlockState st = world.getBlockState(new BlockPos(x, y, z));
      if (st.isAir()) return false;
      if (!st.getFluidState().isEmpty()) return false;
      // any non-air, non-fluid counts as wall/floor material for cavity bounds
      return true;
   }

   private static Hit measureRoom(
      World world,
      int ox, int oy, int oz,
      int minS, int maxS, int minH, int maxH,
      boolean needFloor, boolean needCeil, boolean useLight, int need, long now
   ) {
      // expand along axes from open air seed
      int west = raySolid(world, ox, oy, oz, -1, 0, 0, maxS + 2);
      int east = raySolid(world, ox, oy, oz, 1, 0, 0, maxS + 2);
      int north = raySolid(world, ox, oy, oz, 0, 0, -1, maxS + 2);
      int south = raySolid(world, ox, oy, oz, 0, 0, 1, maxS + 2);
      int down = raySolid(world, ox, oy, oz, 0, -1, 0, maxH + 2);
      int up = raySolid(world, ox, oy, oz, 0, 1, 0, maxH + 2);

      int width = west + east + 1;
      int length = north + south + 1;
      int height = down + up + 1;

      if (width < minS || width > maxS) return null;
      if (length < minS || length > maxS) return null;
      if (height < minH || height > maxH) return null;

      int minX = ox - west;
      int maxX = ox + east;
      int minY = oy - down;
      int maxY = oy + up;
      int minZ = oz - north;
      int maxZ = oz + south;

      // wall / floor / ceiling fill ratios
      int wallSolid = 0, wallTotal = 0;
      int floorSolid = 0, floorTotal = 0;
      int ceilSolid = 0, ceilTotal = 0;
      int airInside = 0, insideTotal = 0;

      // sample faces (step 1 on edges for accuracy)
      for (int y = minY; y <= maxY; y++) {
         for (int z = minZ; z <= maxZ; z++) {
            wallTotal += 2;
            if (isSolidWall(world, minX - 1, y, z)) wallSolid++;
            if (isSolidWall(world, maxX + 1, y, z)) wallSolid++;
         }
         for (int x = minX; x <= maxX; x++) {
            wallTotal += 2;
            if (isSolidWall(world, x, y, minZ - 1)) wallSolid++;
            if (isSolidWall(world, x, y, maxZ + 1)) wallSolid++;
         }
      }
      for (int x = minX; x <= maxX; x++) {
         for (int z = minZ; z <= maxZ; z++) {
            floorTotal++;
            ceilTotal++;
            if (isSolidWall(world, x, minY - 1, z)) floorSolid++;
            if (isSolidWall(world, x, maxY + 1, z)) ceilSolid++;
            // interior openness sample
            insideTotal++;
            if (isAirOpen(world, x, (minY + maxY) >> 1, z)) airInside++;
         }
      }

      if (wallTotal == 0 || floorTotal == 0) return null;
      double wallRatio = (double) wallSolid / wallTotal;
      double floorRatio = (double) floorSolid / floorTotal;
      double ceilRatio = (double) ceilSolid / ceilTotal;
      double airRatio = insideTotal == 0 ? 0 : (double) airInside / insideTotal;

      if (wallRatio < 0.55) return null;
      if (needFloor && floorRatio < 0.55) return null;
      if (needCeil && ceilRatio < 0.45) return null;
      if (airRatio < 0.45) return null;

      // rectangularity: prefer closer to a box (not a long thin tunnel only)
      double aspect = width > length ? (double) width / length : (double) length / width;
      if (aspect > 4.5) return null; // very long corridor — still ok if height room-like but soft reject extreme

      int score = 0;
      score += (int) (wallRatio * 12);
      score += (int) (floorRatio * 8);
      score += (int) (ceilRatio * 6);
      score += (int) (airRatio * 6);
      // size sweet spot
      int avgFoot = (width + length) / 2;
      if (avgFoot >= 6 && avgFoot <= 20) score += 4;
      if (height >= 3 && height <= 8) score += 3;
      if (aspect <= 2.0) score += 3;

      if (useLight) {
         int lx = (minX + maxX) >> 1;
         int ly = (minY + maxY) >> 1;
         int lz = (minZ + maxZ) >> 1;
         int bl = world.getLightLevel(LightType.BLOCK, new BlockPos(lx, ly, lz));
         if (bl >= 1 && bl <= 6) score += 3;
         if (bl == 5) score += 2;
      }

      if (score < need) return null;
      return new Hit(minX, minY, minZ, maxX, maxY, maxZ, score, now);
   }

   private static int raySolid(World world, int x, int y, int z, int dx, int dy, int dz, int max) {
      for (int i = 1; i <= max; i++) {
         int nx = x + dx * i;
         int ny = y + dy * i;
         int nz = z + dz * i;
         if (isSolidWall(world, nx, ny, nz)) {
            return i - 1;
         }
         if (!isAirOpen(world, nx, ny, nz)) {
            return i - 1;
         }
      }
      return max;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      List<Hit> list = this.hits;
      if (list == null || list.isEmpty()) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null || mc.player == null) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null) {
         return;
      }
      Vec3d cam = RenderUtils.getCameraPos(camera);
      Color base = this.color.getValue();
      int a = this.alpha.getValue();

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);

      for (Hit h : list) {
         float strength = Math.min(1.0f, h.score / 28.0f);
         int aa = Math.min(255, (int) (a * (0.45f + 0.55f * strength)));
         Color line = new Color(base.getRed(), base.getGreen(), base.getBlue(), aa);
         double x0 = h.minX - cam.x;
         double y0 = h.minY - cam.y;
         double z0 = h.minZ - cam.z;
         double x1 = h.maxX + 1 - cam.x;
         double y1 = h.maxY + 1 - cam.y;
         double z1 = h.maxZ + 1 - cam.z;
         drawBox(batch, line, x0, y0, z0, x1, y1, z1, h.score >= 18 ? 2.4f : 1.6f);
         // center cross
         double cx = (x0 + x1) * 0.5;
         double cy = (y0 + y1) * 0.5;
         double cz = (z0 + z1) * 0.5;
         batch.renderLine(line, new Vec3d(cx - 0.6, cy, cz), new Vec3d(cx + 0.6, cy, cz), 2.0f);
         batch.renderLine(line, new Vec3d(cx, cy, cz - 0.6), new Vec3d(cx, cy, cz + 0.6), 2.0f);
      }

      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   private static void drawBox(ShapeBatch batch, Color c, double x0, double y0, double z0, double x1, double y1, double z1, float w) {
      // bottom
      batch.renderLine(c, new Vec3d(x0, y0, z0), new Vec3d(x1, y0, z0), w);
      batch.renderLine(c, new Vec3d(x1, y0, z0), new Vec3d(x1, y0, z1), w);
      batch.renderLine(c, new Vec3d(x1, y0, z1), new Vec3d(x0, y0, z1), w);
      batch.renderLine(c, new Vec3d(x0, y0, z1), new Vec3d(x0, y0, z0), w);
      // top
      batch.renderLine(c, new Vec3d(x0, y1, z0), new Vec3d(x1, y1, z0), w);
      batch.renderLine(c, new Vec3d(x1, y1, z0), new Vec3d(x1, y1, z1), w);
      batch.renderLine(c, new Vec3d(x1, y1, z1), new Vec3d(x0, y1, z1), w);
      batch.renderLine(c, new Vec3d(x0, y1, z1), new Vec3d(x0, y1, z0), w);
      // pillars
      batch.renderLine(c, new Vec3d(x0, y0, z0), new Vec3d(x0, y1, z0), w);
      batch.renderLine(c, new Vec3d(x1, y0, z0), new Vec3d(x1, y1, z0), w);
      batch.renderLine(c, new Vec3d(x1, y0, z1), new Vec3d(x1, y1, z1), w);
      batch.renderLine(c, new Vec3d(x0, y0, z1), new Vec3d(x0, y1, z1), w);
   }
}
