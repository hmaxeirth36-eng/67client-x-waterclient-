package com.water.gui;

import com.water.module.modules.client.SpotifyHUD;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;

public class WaterChatScreen extends ChatScreen {
   public WaterChatScreen(String text) {
      super(text == null ? "" : text);
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      try {
         if (click != null && HudEditor.INSTANCE != null) {
            double d0 = click.x();
            double d1 = click.y();
            int i = click.button();
            if (HudEditor.INSTANCE.onMouseClick(d0, d1, i)) {
               return true;
            }
            if (i == 0 && SpotifyHUD.handleClick(d0, d1)) {
               return true;
            }
         }
      } catch (Throwable ignored) {
      }
      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      try {
         if (HudEditor.INSTANCE != null && HudEditor.INSTANCE.isDragging() && click != null) {
            HudEditor.INSTANCE.onMouseDrag(click.x(), click.y());
            return true;
         }
      } catch (Throwable ignored) {
      }
      return super.mouseDragged(click, offsetX, offsetY);
   }

   @Override
   public boolean mouseReleased(Click click) {
      try {
         if (HudEditor.INSTANCE != null) {
            HudEditor.INSTANCE.onMouseRelease();
         }
      } catch (Throwable ignored) {
      }
      return super.mouseReleased(click);
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      super.render(context, mouseX, mouseY, deltaTicks);
      try {
         if (HudEditor.INSTANCE != null && context != null) {
            HudEditor.INSTANCE.render(context, mouseX, mouseY);
         }
      } catch (Throwable ignored) {
      }
   }

   public static String watermarkFragment() {
      return "T";
   }
}
