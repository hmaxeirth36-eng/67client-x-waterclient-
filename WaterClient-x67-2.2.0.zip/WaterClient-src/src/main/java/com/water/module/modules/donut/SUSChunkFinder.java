package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * 67 Sus Chunk Finder — scoring inspired by 67Client + floating % labels.
 *
 * confidence (67 formula):
 *   t = (score - threshold) / (threshold * 2)
 *   confidence = 0.55 + 0.45 * clamp(t, 0, 1)  → 55%..100%
 */
public final class SUSChunkFinder extends Module {
   public static SUSChunkFinder INSTANCE;
   public static final int POINTS_PER_SENSITIVITY = 5;

   public final Setting<Integer> simulationDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 3, 1, 15);
   public final Setting<Boolean> smartMode = new Setting<>("Smart Mode", true);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 10, 2, 24);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 55, 0, 255);
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(255, 50, 50, 55));
   public final Setting<Boolean> showPercent = new Setting<>("Show %", true);

   public final Setting<Boolean> amethyst = new Setting<>("Amethyst", true);
   public final Setting<Boolean> kelp = new Setting<>("Kelp", true);
   public final Setting<Boolean> bamboo = new Setting<>("Bamboo", true);
   public final Setting<Boolean> berries = new Setting<>("Berries", true);
   public final Setting<Boolean> vines = new Setting<>("Vines", true);
   public final Setting<Boolean> dripstone = new Setting<>("Dripstone", true);
   public final Setting<Boolean> light5 = new Setting<>("Light-5 Amethyst", true);

   /** chunk → raw score (only flagged chunks) */
   public volatile Map<ChunkPos, Double> hits = Collections.emptyMap();
   /** last threshold used when building hits */
   public volatile int lastThreshold = 15;

   public static final class LabelPos {
      public float x, y;
      public int percent;
      public long lastOkMs;
   }

   public final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   private ExecutorService scanExec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tickCount = 0;
   private int scanCursor = 0;

   public SUSChunkFinder() {
      super("67 Sus Chunk Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simulationDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.smartMode);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.outline);
      this.addSetting(this.fillColor);
      this.addSetting(this.showPercent);
      this.addSetting(this.amethyst);
      this.addSetting(this.kelp);
      this.addSetting(this.bamboo);
      this.addSetting(this.berries);
      this.addSetting(this.vines);
      this.addSetting(this.dripstone);
      this.addSetting(this.light5);
   }

   /** 67 SusChunkRenderer.confidence → percent 55..100 */
   public static int confidencePercent(double score, int threshold) {
      if (threshold <= 0) return 100;
      float t = (float) ((score - threshold) / (threshold * 2.0));
      if (t < 0f) t = 0f;
      if (t > 1f) t = 1f;
      return Math.round((0.55f + 0.45f * t) * 100f);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.tickCount = 0;
      this.scanCursor = 0;
   }

   @Override
   public void onDisable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.scanning.set(false);
      if (this.scanExec != null) {
         this.scanExec.shutdownNow();
         this.scanExec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tickCount % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.scanExec == null || this.scanExec.isShutdown()) {
         this.scanExec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "water-x67-sus");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simulationDist.getValue();
      final double threshold = this.sensitivity.getValue() * (double) POINTS_PER_SENSITIVITY;
      final boolean smart = this.smartMode.getValue();
      final int batch = this.scanSpeed.getValue();

      final boolean doAm = this.amethyst.getValue();
      final boolean doKelp = this.kelp.getValue();
      final boolean doBamboo = this.bamboo.getValue();
      final boolean doBerries = this.berries.getValue();
      final boolean doVines = this.vines.getValue();
      final boolean doDrip = this.dripstone.getValue();
      final boolean doLight5 = this.light5.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.scanCursor % positions.size();
      this.scanCursor = start + batch;

      final Map<ChunkPos, Double> retained = new HashMap<>();
      for (Map.Entry<ChunkPos, Double> e : this.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         if (Math.abs(cp.x - origin.x) <= radius && Math.abs(cp.z - origin.z) <= radius) {
            retained.put(cp, e.getValue());
         }
      }

      final Map<ChunkPos, Integer> light5Counts = new HashMap<>();
      if (doLight5 && doAm) {
         BlockPos.Mutable mut = new BlockPos.Mutable();
         int endL = Math.min(positions.size(), start + batch);
         for (int i = start; i < endL; i++) {
            ChunkPos cp = positions.get(i);
            int c = countLight5(cp, mut);
            if (c > 0) light5Counts.put(cp, c);
         }
         if (start + batch > positions.size()) {
            for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
               ChunkPos cp = positions.get(i);
               int c = countLight5(cp, mut);
               if (c > 0) light5Counts.put(cp, c);
            }
         }
      }

      this.scanExec.submit(() -> {
         try {
            Map<ChunkPos, Double> next = new HashMap<>(retained);
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            int usedThreshold = (int) Math.round(threshold);

            for (int idx : idxs) {
               if (idx < 0 || idx >= positions.size()) continue;
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               double score = scoreChunk(wc, doAm, doKelp, doBamboo, doBerries, doVines, doDrip);
               int l5 = light5Counts.getOrDefault(cp, 0);
               if (doLight5 && doAm && l5 > 0) {
                  score += Math.min(l5, 16) * 6.0;
               }

               double need = threshold;
               if (smart) {
                  int sec = 0;
                  for (ChunkSection s : wc.getSectionArray()) {
                     if (s != null && !s.isEmpty()) sec++;
                  }
                  if (sec < 8) need *= 0.85;
                  if (sec < 4) need *= 0.75;
               }

               if (score >= need) next.put(cp, score);
               else next.remove(cp);
            }
            this.lastThreshold = usedThreshold;
            this.hits = Collections.unmodifiableMap(next);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private int countLight5(ChunkPos cp, BlockPos.Mutable mut) {
      if (mc.world == null) return 0;
      int count = 0;
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      for (int y = -48; y <= 48; y += 2) {
         for (int x = 0; x < 16; x += 2) {
            for (int z = 0; z < 16; z += 2) {
               mut.set(x0 + x, y, z0 + z);
               if (mc.world.getLightLevel(LightType.BLOCK, mut) == 5) count++;
            }
         }
      }
      return count;
   }

   private static double scoreChunk(
         WorldChunk chunk,
         boolean doAm, boolean doKelp, boolean doBamboo, boolean doBerries, boolean doVines, boolean doDrip
   ) {
      int am = 0, kelpN = 0, bambooN = 0, berryN = 0, vineN = 0, dripN = 0;

      for (ChunkSection section : chunk.getSectionArray()) {
         if (section == null || section.isEmpty()) continue;
         if (!section.hasAny(SUSChunkFinder::isTracked)) continue;

         for (int x = 0; x < 16; x++) {
            for (int y = 0; y < 16; y++) {
               for (int z = 0; z < 16; z++) {
                  BlockState st = section.getBlockState(x, y, z);
                  Block b = st.getBlock();
                  if (doAm && isAmethyst(st)) am++;
                  else if (doKelp && (b == Blocks.KELP || b == Blocks.KELP_PLANT)) kelpN++;
                  else if (doBamboo && (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING)) bambooN++;
                  else if (doBerries && b == Blocks.SWEET_BERRY_BUSH) {
                     if (st.contains(SweetBerryBushBlock.AGE) && st.get(SweetBerryBushBlock.AGE) >= 3) berryN += 2;
                     else berryN++;
                  } else if (doVines && (b == Blocks.VINE || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT)) vineN++;
                  else if (doDrip && (b == Blocks.POINTED_DRIPSTONE || b == Blocks.DRIPSTONE_BLOCK)) dripN++;
               }
            }
         }
      }

      double score = 0;
      if (doAm) score += Math.min(am, 16) * 6.0;
      if (doKelp) score += Math.min(kelpN, 6) * 2.0;
      if (doBamboo) score += Math.min(bambooN, 6) * 2.0;
      if (doBerries) score += Math.min(berryN, 6) * 2.0;
      if (doVines) score += Math.min(vineN, 6) * 2.0;
      if (doDrip) score += Math.min(dripN, 5) * 2.0;
      return score;
   }

   private static boolean isTracked(BlockState st) {
      Block b = st.getBlock();
      return isAmethyst(st)
         || b == Blocks.KELP || b == Blocks.KELP_PLANT
         || b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING
         || b == Blocks.SWEET_BERRY_BUSH
         || b == Blocks.VINE || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT
         || b == Blocks.POINTED_DRIPSTONE || b == Blocks.DRIPSTONE_BLOCK;
   }

   private static boolean isAmethyst(BlockState st) {
      Block b = st.getBlock();
      return b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST
         || b == Blocks.AMETHYST_CLUSTER
         || b == Blocks.SMALL_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.LARGE_AMETHYST_BUD;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, Double> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;

      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);

      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 120));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      GL11.glEnable(GL11.GL_BLEND);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : map.keySet()) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16.0, y2, z1 + 16.0, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16.0, y2, z1 + 16.0, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      SUSChunkFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showPercent.getValue()) return;

      Map<ChunkPos, Double> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }

      int threshold = self.lastThreshold > 0 ? self.lastThreshold : self.sensitivity.getValue() * POINTS_PER_SENSITIVITY;
      double textY = self.renderY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();

      for (Map.Entry<ChunkPos, Double> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         double score = e.getValue();
         int percent = confidencePercent(score, threshold);

         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;

         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.percent = percent;

         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }

         // hold last good position ~0.5s to reduce flicker
         if (now - lp.lastOkMs < 500L && lp.lastOkMs > 0) {
            String line = lp.percent + "%";
            int w = FontRenderer.INSTANCE.getWidth(line);
            int color = lp.percent >= 85 ? 0xFFFF5555 : (lp.percent >= 70 ? 0xFFFFAA00 : 0xFFFFFF55);
            FontRenderer.INSTANCE.drawString(context, line, lp.x - w / 2f + 1, lp.y + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, line, lp.x - w / 2f, lp.y, color);
         }
      }

      self.labelCache.keySet().removeIf(cp -> !keep.contains(cp));
   }
}
