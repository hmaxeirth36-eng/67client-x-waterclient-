package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Rect Cavity — rectangular rooms below Y0 (default). No chest ESP.
 * Tuned for low lag: sparse scan, cheap walls, hit cap, sticky TTL.
 */
public final class RectCavityFinder extends Module {
   public static RectCavityFinder INSTANCE;

   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 3, 1, 6);
   public final Setting<Integer> minSize = new Setting<>("Min Size", 5, 3, 16);
   public final Setting<Integer> maxSize = new Setting<>("Max Size", 24, 8, 40);
   public final Setting<Integer> minHeight = new Setting<>("Min Height", 3, 2, 10);
   public final Setting<Integer> maxHeight = new Setting<>("Max Height", 10, 4, 24);
   /** Default deep only: Y0 and below */
   public final Setting<Integer> minY = new Setting<>("Min Y", -60, -64, 0);
   public final Setting<Integer> maxY = new Setting<>("Max Y", 0, -32, 64);
   public final Setting<Integer> minScore = new Setting<>("Min Score", 14, 4, 40);
   public final Setting<Integer> scanStep = new Setting<>("Scan Step", 3, 2, 6);
   public final Setting<Integer> chunksPerPass = new Setting<>("Chunks Per Pass", 2, 1, 4);
   public final Setting<Boolean> requireFloor = new Setting<>("Require Floor", true);
   public final Setting<Boolean> requireCeiling = new Setting<>("Require Ceiling", true);
   public final Setting<Boolean> lightAssist = new Setting<>("Light Assist", true);
   public final Setting<Boolean> sticky = new Setting<>("Sticky Hits", true);
   public final Setting<Integer> stickySeconds = new Setting<>("Sticky Seconds", 120, 30, 600);
   public final Setting<Integer> maxHits = new Setting<>("Max Hits", 40, 10, 100);
   public final Setting<Integer> alpha = new Setting<>("Alpha", 120, 30, 255);
   public final Setting<Color> color = new Setting<>("Box Color", new Color(255, 140, 40, 120));

   public static final class Hit {
      public final int minX, minY, minZ, maxX, maxY, maxZ;
      public final int score;
      public final long createdMs;
      public volatile long lastSeenMs;

      public Hit(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, int score, long now) {
         this.minX = minX;
         this.minY = minY;
         this.minZ = minZ;
         this.maxX = maxX;
         this.maxY = maxY;
         this.maxZ = maxZ;
         this.score = score;
         this.createdMs = now;
         this.lastSeenMs = now;
      }

      public long key() {
         int cx = (minX + maxX) >> 1;
         int cy = (minY + maxY) >> 1;
         int cz = (minZ + maxZ) >> 1;
         return (((long) (cx >> 3)) & 0x3fffffL) << 42
            | (((long) (cz >> 3)) & 0x3fffffL) << 20
            | (((long) (cy >> 3)) & 0xfffffL);
      }
   }

   public volatile List<Hit> hits = List.of();
   private final Map<Long, Hit> stickyMap = new ConcurrentHashMap<>();
   private int tickCounter;
   private int scanCursor;
   private final BlockPos.Mutable mut = new BlockPos.Mutable();

   public RectCavityFinder() {
      super("Rect Cavity", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simDist);
      this.addSetting(this.minSize);
      this.addSetting(this.maxSize);
      this.addSetting(this.minHeight);
      this.addSetting(this.maxHeight);
      this.addSetting(this.minY);
      this.addSetting(this.maxY);
      this.addSetting(this.minScore);
      this.addSetting(this.scanStep);
      this.addSetting(this.chunksPerPass);
      this.addSetting(this.requireFloor);
      this.addSetting(this.requireCeiling);
      this.addSetting(this.lightAssist);
      this.addSetting(this.sticky);
      this.addSetting(this.stickySeconds);
      this.addSetting(this.maxHits);
      this.addSetting(this.alpha);
      this.addSetting(this.color);
   }

   @Override
   public void onEnable() {
      this.hits = List.of();
      this.scanCursor = 0;
   }

   @Override
   public void onDisable() {
      this.hits = List.of();
      if (!this.sticky.getValue()) {
         this.stickyMap.clear();
      }
   }

   @Override
   public void onTick() {
      try {
         tickInner();
      } catch (Throwable t) {
         // never crash the client from this module
      }
   }

   private void tickInner() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null || mc.player == null) {
         return;
      }
      this.tickCounter++;
      // scan every 4 ticks
      if ((this.tickCounter & 3) != 0) {
         return;
      }

      World world = mc.world;
      ChunkPos playerChunk = mc.player.getChunkPos();
      int radius = this.simDist.getValue();
      int step = Math.max(2, this.scanStep.getValue());
      int y0 = this.minY.getValue();
      int y1 = this.maxY.getValue();
      if (y1 < y0) {
         int tmp = y0;
         y0 = y1;
         y1 = tmp;
      }
      int minS = this.minSize.getValue();
      int maxS = this.maxSize.getValue();
      int minH = this.minHeight.getValue();
      int maxH = this.maxHeight.getValue();
      int need = this.minScore.getValue();
      boolean needFloor = this.requireFloor.getValue();
      boolean needCeil = this.requireCeiling.getValue();
      boolean useLight = this.lightAssist.getValue();
      long now = System.currentTimeMillis();

      List<ChunkPos> order = new ArrayList<>((radius * 2 + 1) * (radius * 2 + 1));
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            order.add(new ChunkPos(playerChunk.x + dx, playerChunk.z + dz));
         }
      }
      if (order.isEmpty()) {
         return;
      }
      this.scanCursor = this.scanCursor % order.size();
      int budget = Math.min(this.chunksPerPass.getValue(), order.size());
      Map<Long, Hit> batch = new HashMap<>();

      for (int b = 0; b < budget; b++) {
         ChunkPos cp = order.get((this.scanCursor + b) % order.size());
         WorldChunk chunk = world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
         if (chunk == null) {
            continue;
         }
         int baseX = cp.getStartX();
         int baseZ = cp.getStartZ();
         // sparse seeds only
         for (int ly = y0; ly <= y1; ly += step) {
            for (int lx = 1; lx < 16; lx += step) {
               for (int lz = 1; lz < 16; lz += step) {
                  int x = baseX + lx;
                  int z = baseZ + lz;
                  if (!isAir(world, x, ly, z)) {
                     continue;
                  }
                  Hit hit = measureRoom(world, x, ly, z, minS, maxS, minH, maxH, needFloor, needCeil, useLight, need, now);
                  if (hit == null) {
                     continue;
                  }
                  long key = hit.key();
                  Hit prev = batch.get(key);
                  if (prev == null || hit.score > prev.score) {
                     batch.put(key, hit);
                  }
               }
            }
         }
      }
      this.scanCursor = (this.scanCursor + budget) % Math.max(1, order.size());

      int cap = this.maxHits.getValue();
      if (this.sticky.getValue()) {
         long ttl = this.stickySeconds.getValue() * 1000L;
         for (Hit h : batch.values()) {
            Hit old = this.stickyMap.get(h.key());
            if (old == null || h.score >= old.score) {
               this.stickyMap.put(h.key(), h);
            } else {
               old.lastSeenMs = now;
            }
         }
         Iterator<Map.Entry<Long, Hit>> it = this.stickyMap.entrySet().iterator();
         while (it.hasNext()) {
            Map.Entry<Long, Hit> e = it.next();
            Hit h = e.getValue();
            if (now - h.lastSeenMs > ttl) {
               it.remove();
            }
         }
         // cap by score
         if (this.stickyMap.size() > cap) {
            List<Hit> sorted = new ArrayList<>(this.stickyMap.values());
            sorted.sort((a, b) -> Integer.compare(b.score, a.score));
            this.stickyMap.clear();
            for (int i = 0; i < Math.min(cap, sorted.size()); i++) {
               Hit h = sorted.get(i);
               this.stickyMap.put(h.key(), h);
            }
         }
         this.hits = List.copyOf(this.stickyMap.values());
      } else {
         this.stickyMap.clear();
         List<Hit> list = new ArrayList<>(batch.values());
         list.sort((a, b) -> Integer.compare(b.score, a.score));
         if (list.size() > cap) {
            list = list.subList(0, cap);
         }
         this.hits = List.copyOf(list);
      }
   }

   private boolean isAir(World world, int x, int y, int z) {
      return world.getBlockState(this.mut.set(x, y, z)).isAir();
   }

   private boolean isSolid(World world, int x, int y, int z) {
      BlockState st = world.getBlockState(this.mut.set(x, y, z));
      return !st.isAir() && st.getFluidState().isEmpty();
   }

   private Hit measureRoom(
      World world,
      int ox, int oy, int oz,
      int minS, int maxS, int minH, int maxH,
      boolean needFloor, boolean needCeil, boolean useLight, int need, long now
   ) {
      int west = ray(world, ox, oy, oz, -1, 0, 0, maxS + 1);
      int east = ray(world, ox, oy, oz, 1, 0, 0, maxS + 1);
      int north = ray(world, ox, oy, oz, 0, 0, -1, maxS + 1);
      int south = ray(world, ox, oy, oz, 0, 0, 1, maxS + 1);
      int down = ray(world, ox, oy, oz, 0, -1, 0, maxH + 1);
      int up = ray(world, ox, oy, oz, 0, 1, 0, maxH + 1);

      int width = west + east + 1;
      int length = north + south + 1;
      int height = down + up + 1;
      if (width < minS || width > maxS) return null;
      if (length < minS || length > maxS) return null;
      if (height < minH || height > maxH) return null;

      int minX = ox - west;
      int maxX = ox + east;
      int minY = oy - down;
      int maxY = oy + up;
      int minZ = oz - north;
      int maxZ = oz + south;

      // cheap face samples (corners + midpoints only) instead of full faces
      int wallOk = 0;
      int wallN = 0;
      int[][] samples = {
         {minX - 1, (minY + maxY) >> 1, minZ},
         {maxX + 1, (minY + maxY) >> 1, minZ},
         {minX - 1, (minY + maxY) >> 1, maxZ},
         {maxX + 1, (minY + maxY) >> 1, maxZ},
         {(minX + maxX) >> 1, (minY + maxY) >> 1, minZ - 1},
         {(minX + maxX) >> 1, (minY + maxY) >> 1, maxZ + 1},
         {minX, (minY + maxY) >> 1, minZ - 1},
         {maxX, (minY + maxY) >> 1, maxZ + 1}
      };
      for (int[] s : samples) {
         wallN++;
         if (isSolid(world, s[0], s[1], s[2])) wallOk++;
      }
      double wallRatio = (double) wallOk / wallN;
      if (wallRatio < 0.5) return null;

      int floorOk = 0, ceilOk = 0, n = 0;
      for (int i = 0; i < 4; i++) {
         int fx = minX + (i % 2) * (maxX - minX);
         int fz = minZ + (i / 2) * (maxZ - minZ);
         n++;
         if (isSolid(world, fx, minY - 1, fz)) floorOk++;
         if (isSolid(world, fx, maxY + 1, fz)) ceilOk++;
      }
      // center floor/ceil
      n++;
      if (isSolid(world, (minX + maxX) >> 1, minY - 1, (minZ + maxZ) >> 1)) floorOk++;
      if (isSolid(world, (minX + maxX) >> 1, maxY + 1, (minZ + maxZ) >> 1)) ceilOk++;

      double floorRatio = (double) floorOk / n;
      double ceilRatio = (double) ceilOk / n;
      if (needFloor && floorRatio < 0.5) return null;
      if (needCeil && ceilRatio < 0.4) return null;

      double aspect = width > length ? (double) width / length : (double) length / width;
      if (aspect > 4.0) return null;

      int score = 0;
      score += (int) (wallRatio * 10);
      score += (int) (floorRatio * 7);
      score += (int) (ceilRatio * 5);
      int avgFoot = (width + length) / 2;
      if (avgFoot >= 6 && avgFoot <= 18) score += 4;
      if (height >= 3 && height <= 7) score += 3;
      if (aspect <= 2.0) score += 3;

      if (useLight) {
         int bl = world.getLightLevel(LightType.BLOCK, this.mut.set((minX + maxX) >> 1, (minY + maxY) >> 1, (minZ + maxZ) >> 1));
         if (bl >= 1 && bl <= 6) score += 3;
         if (bl == 5) score += 2;
      }

      if (score < need) return null;
      return new Hit(minX, minY, minZ, maxX, maxY, maxZ, score, now);
   }

   private int ray(World world, int x, int y, int z, int dx, int dy, int dz, int max) {
      for (int i = 1; i <= max; i++) {
         if (isSolid(world, x + dx * i, y + dy * i, z + dz * i)) {
            return i - 1;
         }
         if (!isAir(world, x + dx * i, y + dy * i, z + dz * i)) {
            return i - 1;
         }
      }
      return max;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      try {
         renderInner(matrices);
      } catch (Throwable t) {
         // swallow render errors
      }
   }

   private void renderInner(MatrixStack matrices) {
      List<Hit> list = this.hits;
      if (list == null || list.isEmpty()) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world == null || mc.player == null) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null) {
         return;
      }
      Vec3d cam = RenderUtils.getCameraPos(camera);
      if (cam == null) {
         return;
      }
      Color base = this.color.getValue();
      int a = this.alpha.getValue();

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);

      int drawn = 0;
      int drawCap = this.maxHits.getValue();
      for (Hit h : list) {
         if (drawn >= drawCap) break;
         float strength = Math.min(1.0f, h.score / 28.0f);
         int aa = Math.min(255, (int) (a * (0.45f + 0.55f * strength)));
         Color line = new Color(base.getRed(), base.getGreen(), base.getBlue(), aa);
         double x0 = h.minX - cam.x;
         double y0 = h.minY - cam.y;
         double z0 = h.minZ - cam.z;
         double x1 = h.maxX + 1 - cam.x;
         double y1 = h.maxY + 1 - cam.y;
         double z1 = h.maxZ + 1 - cam.z;
         drawBox(batch, line, x0, y0, z0, x1, y1, z1, h.score >= 18 ? 2.2f : 1.5f);
         double cx = (x0 + x1) * 0.5;
         double cy = (y0 + y1) * 0.5;
         double cz = (z0 + z1) * 0.5;
         batch.renderLine(line, new Vec3d(cx - 0.5, cy, cz), new Vec3d(cx + 0.5, cy, cz), 1.8f);
         batch.renderLine(line, new Vec3d(cx, cy, cz - 0.5), new Vec3d(cx, cy, cz + 0.5), 1.8f);
         drawn++;
      }

      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   private static void drawBox(ShapeBatch batch, Color c, double x0, double y0, double z0, double x1, double y1, double z1, float w) {
      batch.renderLine(c, new Vec3d(x0, y0, z0), new Vec3d(x1, y0, z0), w);
      batch.renderLine(c, new Vec3d(x1, y0, z0), new Vec3d(x1, y0, z1), w);
      batch.renderLine(c, new Vec3d(x1, y0, z1), new Vec3d(x0, y0, z1), w);
      batch.renderLine(c, new Vec3d(x0, y0, z1), new Vec3d(x0, y0, z0), w);
      batch.renderLine(c, new Vec3d(x0, y1, z0), new Vec3d(x1, y1, z0), w);
      batch.renderLine(c, new Vec3d(x1, y1, z0), new Vec3d(x1, y1, z1), w);
      batch.renderLine(c, new Vec3d(x1, y1, z1), new Vec3d(x0, y1, z1), w);
      batch.renderLine(c, new Vec3d(x0, y1, z1), new Vec3d(x0, y1, z0), w);
      batch.renderLine(c, new Vec3d(x0, y0, z0), new Vec3d(x0, y1, z0), w);
      batch.renderLine(c, new Vec3d(x1, y0, z0), new Vec3d(x1, y1, z0), w);
      batch.renderLine(c, new Vec3d(x1, y0, z1), new Vec3d(x1, y1, z1), w);
      batch.renderLine(c, new Vec3d(x0, y0, z1), new Vec3d(x0, y1, z1), w);
   }
}
