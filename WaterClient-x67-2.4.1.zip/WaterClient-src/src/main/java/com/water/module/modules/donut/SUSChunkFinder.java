package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * 67 Sus Chunk Finder — closer port of 67Client logic:
 * - Signal weights: AMETHYST 6 (cap 16), growth 2 (cap 6/5)
 * - Threshold = sensitivity * 5
 * - Amethyst via blocks + ServerLightCache (light packet driven, light==5)
 * - Growth via column height (kelp/bamboo tops only), max-age berries, long dripstone
 * - confidence % = 55 + 45 * clamp((score-th)/(th*2), 0, 1)
 */
public final class SUSChunkFinder extends Module {
   public static SUSChunkFinder INSTANCE;
   public static final int POINTS_PER_SENSITIVITY = 5;

   public final Setting<Integer> simulationDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 6, 1, 20);
   public final Setting<Boolean> smartMode = new Setting<>("Smart Mode", true);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 8, 2, 24);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 55, 0, 255);
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(255, 50, 50, 55));
   public final Setting<Boolean> showPercent = new Setting<>("Show %", true);

   public final Setting<Boolean> amethyst = new Setting<>("Amethyst", true);
   public final Setting<Boolean> kelp = new Setting<>("Kelp", true);
   public final Setting<Boolean> bamboo = new Setting<>("Bamboo", true);
   public final Setting<Boolean> berries = new Setting<>("Berries", true);
   public final Setting<Boolean> vines = new Setting<>("Vines", false);
   public final Setting<Boolean> dripstone = new Setting<>("Dripstone", true);
   public final Setting<Boolean> light5 = new Setting<>("Light-5 Amethyst", true);
   public final Setting<Integer> minLight5 = new Setting<>("Min Light-5 Cells", 8, 1, 64);
   public final Setting<Integer> minKelpHeight = new Setting<>("Min Kelp Height", 8, 3, 25);
   public final Setting<Integer> minBambooHeight = new Setting<>("Min Bamboo Height", 10, 3, 16);

   public volatile Map<ChunkPos, Double> hits = Collections.emptyMap();
   public volatile int lastThreshold = 30;

   public static final class LabelPos {
      public float x, y;
      public int percent;
      public long lastOkMs;
   }

   public final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   private ExecutorService scanExec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tickCount = 0;
   private int scanCursor = 0;

   public SUSChunkFinder() {
      super("67 Sus Chunk Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simulationDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.smartMode);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.outline);
      this.addSetting(this.fillColor);
      this.addSetting(this.showPercent);
      this.addSetting(this.amethyst);
      this.addSetting(this.kelp);
      this.addSetting(this.bamboo);
      this.addSetting(this.berries);
      this.addSetting(this.vines);
      this.addSetting(this.dripstone);
      this.addSetting(this.light5);
      this.addSetting(this.minLight5);
      this.addSetting(this.minKelpHeight);
      this.addSetting(this.minBambooHeight);
   }

   public static int confidencePercent(double score, int threshold) {
      if (threshold <= 0) return 100;
      float t = (float) ((score - threshold) / (threshold * 2.0));
      if (t < 0f) t = 0f;
      if (t > 1f) t = 1f;
      return Math.round((0.55f + 0.45f * t) * 100f);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.tickCount = 0;
      this.scanCursor = 0;
   }

   @Override
   public void onDisable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.scanning.set(false);
      if (this.scanExec != null) {
         this.scanExec.shutdownNow();
         this.scanExec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;

      // 67-style: only (re)sample light when server sent light packets
      ServerLightCache.INSTANCE.flushDirty(mc);

      if (++this.tickCount % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.scanExec == null || this.scanExec.isShutdown()) {
         this.scanExec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "67-sus-scan");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simulationDist.getValue();
      final double threshold = this.sensitivity.getValue() * (double) POINTS_PER_SENSITIVITY;
      final boolean smart = this.smartMode.getValue();
      final int batch = this.scanSpeed.getValue();

      final boolean doAm = this.amethyst.getValue();
      final boolean doKelp = this.kelp.getValue();
      final boolean doBamboo = this.bamboo.getValue();
      final boolean doBerries = this.berries.getValue();
      final boolean doVines = this.vines.getValue();
      final boolean doDrip = this.dripstone.getValue();
      final boolean doLight5 = this.light5.getValue();
      final int minL5 = this.minLight5.getValue();
      final int minKelpH = this.minKelpHeight.getValue();
      final int minBambooH = this.minBambooHeight.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.scanCursor % positions.size();
      this.scanCursor = start + batch;

      final Map<ChunkPos, Double> retained = new HashMap<>();
      for (Map.Entry<ChunkPos, Double> e : this.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         if (Math.abs(cp.x - origin.x) <= radius && Math.abs(cp.z - origin.z) <= radius) {
            retained.put(cp, e.getValue());
         }
      }

      // Snapshot light5 counts on client thread
      final Map<ChunkPos, Integer> lightSnap = new HashMap<>();
      if (doLight5 && doAm) {
         for (ChunkPos cp : positions) {
            int c = ServerLightCache.INSTANCE.getLight5Count(cp);
            if (c > 0) lightSnap.put(cp, c);
         }
      }

      final World world = mc.world;

      this.scanExec.submit(() -> {
         try {
            Map<ChunkPos, Double> next = new HashMap<>(retained);
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            int usedTh = (int) Math.round(threshold);

            for (int idx : idxs) {
               if (idx < 0 || idx >= positions.size()) continue;
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);

               double score = scoreGrowthAndAmethyst(
                  world, wc, cp, doAm, doKelp, doBamboo, doBerries, doVines, doDrip, minKelpH, minBambooH);

               int l5 = lightSnap.getOrDefault(cp, 0);
               if (doLight5 && doAm && l5 >= minL5) {
                  // 67: amethyst signal from light5 cells, weight 6, cap 16
                  score += Math.min(l5, 16) * 6.0;
               }

               double need = threshold;
               if (smart) {
                  int sec = 0;
                  for (ChunkSection s : wc.getSectionArray()) {
                     if (s != null && !s.isEmpty()) sec++;
                  }
                  // incomplete data → harder to flag (fewer false positives)
                  if (sec < 6) need *= 1.2;
                  if (sec < 3) need *= 1.4;
               }

               if (score >= need) next.put(cp, score);
               else next.remove(cp);
            }
            this.lastThreshold = usedTh;
            this.hits = Collections.unmodifiableMap(next);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   /**
    * Growth detection closer to 67 inspectPlant + columnLength:
    * only count kelp/bamboo column tops with sufficient height.
    */
   private static double scoreGrowthAndAmethyst(
         World world, WorldChunk chunk, ChunkPos cp,
         boolean doAm, boolean doKelp, boolean doBamboo, boolean doBerries, boolean doVines, boolean doDrip,
         int minKelpH, int minBambooH
   ) {
      int amBlocks = 0;
      int kelpCols = 0, bambooCols = 0, berryMax = 0, vineN = 0, dripCols = 0;

      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      BlockPos.Mutable mut2 = new BlockPos.Mutable();

      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();
                  int wx = x0 + lx;
                  int wy = baseY + ly;
                  int wz = z0 + lz;

                  if (doAm && isAmethyst(st)) {
                     amBlocks++;
                     continue;
                  }

                  if (doBerries && b == Blocks.SWEET_BERRY_BUSH) {
                     if (st.contains(SweetBerryBushBlock.AGE) && st.get(SweetBerryBushBlock.AGE) >= 3) {
                        berryMax++;
                     }
                     continue;
                  }

                  if (doVines && (b == Blocks.VINE || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT)) {
                     vineN++;
                     continue;
                  }

                  // Kelp: only column top, height downward
                  if (doKelp && (b == Blocks.KELP || b == Blocks.KELP_PLANT)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.KELP) || above.isOf(Blocks.KELP_PLANT)) continue;
                     int h = columnLength(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.KELP, Blocks.KELP_PLANT);
                     if (h >= minKelpH) kelpCols++;
                     continue;
                  }

                  // Bamboo: column top only
                  if (doBamboo && (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.BAMBOO) || above.isOf(Blocks.BAMBOO_SAPLING)) continue;
                     int h = columnLength(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.BAMBOO, Blocks.BAMBOO_SAPLING);
                     if (h >= minBambooH) bambooCols++;
                     continue;
                  }

                  // Pointed dripstone long columns
                  if (doDrip && b == Blocks.POINTED_DRIPSTONE) {
                     mut.set(wx, wy + 1, wz);
                     if (world.getBlockState(mut).isOf(Blocks.POINTED_DRIPSTONE)) continue;
                     int h = columnLength(world, mut2.set(wx, wy, wz), Direction.DOWN, Blocks.POINTED_DRIPSTONE);
                     if (h >= 5) dripCols++;
                  }
               }
            }
         }
      }

      // 67 weights + caps
      double score = 0;
      if (doAm && amBlocks >= 4) score += Math.min(amBlocks, 16) * 6.0;
      if (doKelp && kelpCols >= 1) score += Math.min(kelpCols, 6) * 2.0;
      if (doBamboo && bambooCols >= 1) score += Math.min(bambooCols, 6) * 2.0;
      if (doBerries && berryMax >= 2) score += Math.min(berryMax, 6) * 2.0;
      if (doVines && vineN >= 24) score += Math.min(vineN / 4, 6) * 2.0;
      if (doDrip && dripCols >= 1) score += Math.min(dripCols, 5) * 2.0;
      return score;
   }

   private static int columnLength(World world, BlockPos.Mutable pos, Direction dir, Block... match) {
      int n = 0;
      for (int i = 0; i < 32; i++) {
         BlockState st = world.getBlockState(pos);
         boolean ok = false;
         for (Block b : match) {
            if (st.isOf(b)) { ok = true; break; }
         }
         if (!ok) break;
         n++;
         pos.move(dir);
      }
      return n;
   }

   private static boolean isAmethyst(BlockState st) {
      Block b = st.getBlock();
      return b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST
         || b == Blocks.AMETHYST_CLUSTER
         || b == Blocks.SMALL_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.LARGE_AMETHYST_BUD;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, Double> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;

      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);

      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 120));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      GL11.glEnable(GL11.GL_BLEND);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : map.keySet()) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16.0, y2, z1 + 16.0, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16.0, y2, z1 + 16.0, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      SUSChunkFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showPercent.getValue()) return;

      Map<ChunkPos, Double> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }

      int threshold = self.lastThreshold > 0 ? self.lastThreshold : self.sensitivity.getValue() * POINTS_PER_SENSITIVITY;
      double textY = self.renderY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();

      for (Map.Entry<ChunkPos, Double> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         int percent = confidencePercent(e.getValue(), threshold);
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;

         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.percent = percent;

         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }

         if (now - lp.lastOkMs < 500L && lp.lastOkMs > 0) {
            // Banner style: "67" tag + percent under it
            String tag = "67";
            String pct = lp.percent + "%";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            int pw = FontRenderer.INSTANCE.getWidth(pct);
            float tx = lp.x - tw / 2f;
            float ty = lp.y - 6f;
            // dark outline for readability
            FontRenderer.INSTANCE.drawString(context, tag, tx + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, tx, ty, 0xFFFF5555);
            FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f + 1, ty + 11, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f, ty + 10, 0xFFFFCCCC);
         }
      }
      self.labelCache.keySet().removeIf(cp -> !keep.contains(cp));
   }
}
