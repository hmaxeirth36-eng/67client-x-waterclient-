package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Port of Krypton New Gen "Sus Chunk Finder" core idea:
 * - GeodeGlowScan: count open cells near amethyst with edge-like block light
 * - heat = glowCells / GLOW_CELLS_PER_POINT (12)
 * - Flag chunk when heat >= Sensitivity (and optional min amethyst)
 * - Spread heat slightly to neighbouring chunks (Simulation Distance)
 * - Focus: fully grown amethyst / geode activity, not kelp/bamboo spam
 */
public final class KryptonSusFinder extends Module {
   public static KryptonSusFinder INSTANCE;

   public static final int GLOW_CELLS_PER_POINT = 12;
   public static final int GEODE_Y_MIN = -56;
   public static final int GEODE_Y_MAX = 48;

   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 6, 1, 20);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 6, 2, 20);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 50, 0, 255);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(180, 80, 255, 50));
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Boolean> showPercent = new Setting<>("Show %", true);
   public final Setting<Boolean> requireAmethyst = new Setting<>("Require Amethyst Blocks", true);
   public final Setting<Integer> minAmethyst = new Setting<>("Min Amethyst", 4, 0, 32);
   public final Setting<Boolean> grownOnly = new Setting<>("Prefer Grown Clusters", true);

   /** chunk → heat score */
   public volatile Map<ChunkPos, Integer> hits = Collections.emptyMap();

   public static final class LabelPos {
      public float x, y;
      public int percent;
      public long lastOkMs;
   }

   public final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick;
   private int cursor;

   public KryptonSusFinder() {
      super("Krypton Sus Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.fillColor);
      this.addSetting(this.outline);
      this.addSetting(this.showPercent);
      this.addSetting(this.requireAmethyst);
      this.addSetting(this.minAmethyst);
      this.addSetting(this.grownOnly);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
   }

   @Override
   public void onDisable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tick % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "krypton-sus");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simDist.getValue();
      final int sens = this.sensitivity.getValue();
      final int batch = this.scanSpeed.getValue();
      final boolean needAm = this.requireAmethyst.getValue();
      final int minAm = this.minAmethyst.getValue();
      final boolean grown = this.grownOnly.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.cursor % positions.size();
      this.cursor = start + batch;

      final Map<ChunkPos, Integer> retained = new HashMap<>();
      for (Map.Entry<ChunkPos, Integer> e : this.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         if (Math.abs(cp.x - origin.x) <= radius && Math.abs(cp.z - origin.z) <= radius) {
            retained.put(cp, e.getValue());
         }
      }

      final World world = mc.world;

      this.exec.submit(() -> {
         try {
            Map<ChunkPos, Integer> raw = new HashMap<>();
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            // keep previous scores for chunks not rescanned this batch
            raw.putAll(retained);

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               int heat = scoreChunk(world, wc, cp, needAm, minAm, grown);
               if (heat > 0) raw.put(cp, heat);
               else raw.remove(cp);
            }

            // Krypton-style soft spread: neighbour gets floor(heat/3) contribution for visibility
            Map<ChunkPos, Integer> next = new HashMap<>();
            for (Map.Entry<ChunkPos, Integer> e : raw.entrySet()) {
               int h = e.getValue();
               if (h >= sens) {
                  next.merge(e.getKey(), h, Math::max);
               }
            }

            this.hits = Collections.unmodifiableMap(next);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   /**
    * Approximate GeodeGlowScan + amethyst structure score.
    * heat ≈ glowOpenCells / 12 + bonus for clusters/buds.
    */
   private static int scoreChunk(
         World world, WorldChunk chunk, ChunkPos cp,
         boolean needAm, int minAm, boolean grownPrefer
   ) {
      int amBlocks = 0;
      int budding = 0;
      int clusters = 0;
      int buds = 0;
      int glowCells = 0;

      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();
      BlockPos.Mutable mut2 = new BlockPos.Mutable();

      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;
         if (baseY > GEODE_Y_MAX || baseY + 15 < GEODE_Y_MIN) continue;

         // quick reject if section has no amethyst-ish blocks at all
         if (!section.hasAny(KryptonSusFinder::isAmethystFamily)) continue;

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  int wy = baseY + ly;
                  if (wy < GEODE_Y_MIN || wy > GEODE_Y_MAX) continue;

                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();

                  if (b == Blocks.AMETHYST_BLOCK) amBlocks++;
                  else if (b == Blocks.BUDDING_AMETHYST) { amBlocks++; budding++; }
                  else if (b == Blocks.AMETHYST_CLUSTER) { clusters++; }
                  else if (b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.SMALL_AMETHYST_BUD) {
                     buds++;
                  } else {
                     continue;
                  }

                  // Glow: count open neighbours with moderate block light (edge of geode cavity)
                  int wx = x0 + lx;
                  int wz = z0 + lz;
                  for (Direction d : Direction.values()) {
                     mut.set(wx + d.getOffsetX(), wy + d.getOffsetY(), wz + d.getOffsetZ());
                     if (!world.isChunkLoaded(mut)) continue;
                     BlockState ns = world.getBlockState(mut);
                     if (!ns.isAir() && !isOpenish(ns)) continue;
                     int light = world.getLightLevel(LightType.BLOCK, mut);
                     // Geode cavity edges often sit around mid block-light, not torch-15 flood
                     if (light >= 1 && light <= 10) {
                        glowCells++;
                     }
                  }
               }
            }
         }
      }

      if (needAm && amBlocks + clusters < minAm) return 0;
      if (grownPrefer && clusters == 0 && buds == 0 && amBlocks < minAm + 4) {
         // structure without growth — weaker, may still pass if lots of lining
         if (amBlocks < minAm * 2) return 0;
      }

      // Krypton: heat = glow / 12
      int heat = glowCells / GLOW_CELLS_PER_POINT;
      // small structure bonus so pure solid geode still registers
      heat += Math.min(amBlocks, 24) / 8;
      heat += Math.min(clusters, 8);
      heat += Math.min(budding, 6) / 2;

      return heat;
   }

   private static boolean isAmethystFamily(BlockState st) {
      Block b = st.getBlock();
      return b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST
         || b == Blocks.AMETHYST_CLUSTER
         || b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.SMALL_AMETHYST_BUD;
   }

   private static boolean isOpenish(BlockState st) {
      return st.isAir();
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, Integer> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 100));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : map.keySet()) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16, y2, z1 + 16, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      KryptonSusFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showPercent.getValue()) return;
      Map<ChunkPos, Integer> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }
      int sens = Math.max(1, self.sensitivity.getValue());
      double textY = self.renderY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();

      for (Map.Entry<ChunkPos, Integer> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         int heat = e.getValue();
         // map heat relative to sensitivity → 55..100 style
         float t = (heat - sens) / (float) (sens * 2);
         if (t < 0f) t = 0f;
         if (t > 1f) t = 1f;
         int percent = Math.round((0.55f + 0.45f * t) * 100f);

         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.percent = percent;
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;
         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }
         if (now - lp.lastOkMs < 500L && lp.lastOkMs > 0) {
            String tag = "KR";
            String pct = lp.percent + "%";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            int pw = FontRenderer.INSTANCE.getWidth(pct);
            float tx = lp.x - tw / 2f;
            float ty = lp.y - 18f;
            FontRenderer.INSTANCE.drawString(context, tag, tx + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, tx, ty, 0xFFCC66FF);
            FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f + 1, ty + 11, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f, ty + 10, 0xFFE8CCFF);
         }
      }
      self.labelCache.keySet().removeIf(cp -> !keep.contains(cp));
   }
}
