package com.water.module.modules.donut;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

/**
 * 67Client-style: only sample light==5 after server light/chunk packets for that chunk.
 */
public final class ServerLightCache {
   public static final ServerLightCache INSTANCE = new ServerLightCache();
   public static final int SCAN_Y_MIN = -56;
   public static final int SCAN_Y_MAX = 48;

   private final Map<Long, Integer> light5Count = new ConcurrentHashMap<>();
   private final Set<Long> dirty = ConcurrentHashMap.newKeySet();

   private ServerLightCache() {}

   public void clear() {
      this.light5Count.clear();
      this.dirty.clear();
   }

   public void onLightPacket(int chunkX, int chunkZ) {
      this.dirty.add(ChunkPos.toLong(chunkX, chunkZ));
   }

   public void flushDirty(MinecraftClient mc) {
      if (mc == null || mc.world == null || this.dirty.isEmpty()) return;
      World world = mc.world;
      BlockPos.Mutable mut = new BlockPos.Mutable();
      List<Long> batch = new ArrayList<>(Math.min(8, this.dirty.size()));
      int n = 0;
      for (Long key : this.dirty) {
         if (n >= 6) break;
         batch.add(key);
         n++;
      }
      for (Long key : batch) this.dirty.remove(key);

      for (Long key : batch) {
         ChunkPos cp = new ChunkPos(key);
         int count = sampleLight5(world, cp.x, cp.z, mut);
         long k = ChunkPos.toLong(cp.x, cp.z);
         if (count > 0) this.light5Count.put(k, count);
         else this.light5Count.remove(k);
      }
   }

   private static int sampleLight5(World world, int chunkX, int chunkZ, BlockPos.Mutable mut) {
      int count = 0;
      int x0 = chunkX << 4;
      int z0 = chunkZ << 4;
      for (int y = SCAN_Y_MIN; y <= SCAN_Y_MAX; y += 2) {
         for (int x = 0; x < 16; x += 2) {
            for (int z = 0; z < 16; z += 2) {
               mut.set(x0 + x, y, z0 + z);
               if (!world.isChunkLoaded(mut)) continue;
               if (world.getLightLevel(LightType.BLOCK, mut) == 5) count++;
            }
         }
      }
      return count;
   }

   public int getLight5Count(ChunkPos cp) {
      Integer v = this.light5Count.get(ChunkPos.toLong(cp.x, cp.z));
      return v == null ? 0 : v;
   }
}
