package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PillarBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Krypton Sus Finder — classic Krypton (krypton1.21.11) style:
 * Sensitivity = minimum "grown / sus signals" to flag a chunk.
 * Toggles: Kelp, Cave Vines, Vines, Amethyst, Bamboo, Bee Nest, Rotated Deepslate.
 * Optional Geode Glow (New Gen-ish heat) as extra signal points.
 * Banner label: KR
 */
public final class KryptonSusFinder extends Module {
   public static KryptonSusFinder INSTANCE;

   public final Setting<Integer> simDist = new Setting<>("Simulation Dist", 5, 1, 12);
   /** Classic: minimum grown things needed to mark chunk as sus */
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 3, 1, 30);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 8, 2, 24);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 50, 0, 255);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(180, 80, 255, 50));
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Boolean> showPercent = new Setting<>("Show %", true);

   public final Setting<Boolean> kelp = new Setting<>("Kelp", true);
   public final Setting<Boolean> caveVines = new Setting<>("Cave Vines", true);
   public final Setting<Boolean> vines = new Setting<>("Vines", true);
   public final Setting<Boolean> amethyst = new Setting<>("Amethyst", true);
   public final Setting<Boolean> bamboo = new Setting<>("Bamboo", true);
   public final Setting<Boolean> beeNest = new Setting<>("Bee Nest", true);
   public final Setting<Boolean> rotatedDeepslate = new Setting<>("Rotated Deepslate", true);
   /** Optional New Gen-style glow contribution (adds to count when high) */
   public final Setting<Boolean> geodeGlow = new Setting<>("Geode Glow Bonus", false);

   public volatile Map<ChunkPos, Integer> hits = Collections.emptyMap();

   public static final class LabelPos {
      public float x, y;
      public int percent;
      public long lastOkMs;
   }

   public final Map<ChunkPos, LabelPos> labelCache = new ConcurrentHashMap<>();
   private final ProjectedPoint projected = new ProjectedPoint();

   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick;
   private int cursor;

   public KryptonSusFinder() {
      super("Krypton Sus Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.fillColor);
      this.addSetting(this.outline);
      this.addSetting(this.showPercent);
      this.addSetting(this.kelp);
      this.addSetting(this.caveVines);
      this.addSetting(this.vines);
      this.addSetting(this.amethyst);
      this.addSetting(this.bamboo);
      this.addSetting(this.beeNest);
      this.addSetting(this.rotatedDeepslate);
      this.addSetting(this.geodeGlow);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
   }

   @Override
   public void onDisable() {
      this.hits = Collections.emptyMap();
      this.labelCache.clear();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tick % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "krypton-classic-sus");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simDist.getValue();
      final int sens = this.sensitivity.getValue();
      final int batch = this.scanSpeed.getValue();

      final boolean doKelp = this.kelp.getValue();
      final boolean doCave = this.caveVines.getValue();
      final boolean doVines = this.vines.getValue();
      final boolean doAm = this.amethyst.getValue();
      final boolean doBamboo = this.bamboo.getValue();
      final boolean doBee = this.beeNest.getValue();
      final boolean doRot = this.rotatedDeepslate.getValue();
      final boolean doGlow = this.geodeGlow.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.cursor % positions.size();
      this.cursor = start + batch;

      final Map<ChunkPos, Integer> retained = new HashMap<>();
      for (Map.Entry<ChunkPos, Integer> e : this.hits.entrySet()) {
         ChunkPos cp = e.getKey();
         if (Math.abs(cp.x - origin.x) <= radius && Math.abs(cp.z - origin.z) <= radius) {
            retained.put(cp, e.getValue());
         }
      }

      final World world = mc.world;

      this.exec.submit(() -> {
         try {
            Map<ChunkPos, Integer> next = new HashMap<>(retained);
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            for (int idx : idxs) {
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               int grown = countGrown(
                  world, wc, cp,
                  doKelp, doCave, doVines, doAm, doBamboo, doBee, doRot, doGlow
               );
               if (grown >= sens) next.put(cp, grown);
               else next.remove(cp);
            }
            this.hits = Collections.unmodifiableMap(next);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   /**
    * Classic Krypton: count discrete "grown / sus" signals in the chunk.
    * Each qualifying plant column top / nest / amethyst cluster / rotated deepslate etc. +1.
    */
   private static int countGrown(
         World world, WorldChunk chunk, ChunkPos cp,
         boolean doKelp, boolean doCave, boolean doVines, boolean doAm,
         boolean doBamboo, boolean doBee, boolean doRot, boolean doGlow
   ) {
      int count = 0;
      int glowCells = 0;
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      BlockPos.Mutable mut = new BlockPos.Mutable();

      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int si = 0; si < sections.length; si++) {
         ChunkSection section = sections[si];
         if (section == null || section.isEmpty()) continue;
         int baseY = bottom + si * 16;

         if (!section.hasAny(st -> isInteresting(st, doKelp, doCave, doVines, doAm, doBamboo, doBee, doRot))) {
            continue;
         }

         for (int lx = 0; lx < 16; lx++) {
            for (int ly = 0; ly < 16; ly++) {
               for (int lz = 0; lz < 16; lz++) {
                  BlockState st = section.getBlockState(lx, ly, lz);
                  Block b = st.getBlock();
                  int wx = x0 + lx;
                  int wy = baseY + ly;
                  int wz = z0 + lz;

                  // Kelp: only top of column, preferably high age
                  if (doKelp && (b == Blocks.KELP || b == Blocks.KELP_PLANT)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.KELP) || above.isOf(Blocks.KELP_PLANT)) continue;
                     int age = 0;
                     if (st.contains(Properties.AGE_25)) age = st.get(Properties.AGE_25);
                     // grown kelp tops or tall plant tops
                     if (b == Blocks.KELP && age >= 20) count++;
                     else if (columnLen(world, wx, wy, wz, Direction.DOWN, Blocks.KELP, Blocks.KELP_PLANT) >= 8) count++;
                     continue;
                  }

                  // Cave vines: berries / plant tip
                  if (doCave && (b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT)) {
                     mut.set(wx, wy - 1, wz);
                     BlockState below = world.getBlockState(mut);
                     if (below.isOf(Blocks.CAVE_VINES) || below.isOf(Blocks.CAVE_VINES_PLANT)) continue;
                     boolean berries = st.contains(Properties.BERRIES) && st.get(Properties.BERRIES);
                     if (berries || columnLen(world, wx, wy, wz, Direction.UP, Blocks.CAVE_VINES, Blocks.CAVE_VINES_PLANT) >= 6) {
                        count++;
                     }
                     continue;
                  }

                  // Normal vines: count sparse (every patch, not every block)
                  if (doVines && b == Blocks.VINE) {
                     // sample: only if one neighbor axis is "new" - count 1 per 8 vine blocks roughly
                     if (((wx + wy + wz) & 7) == 0) count++;
                     continue;
                  }

                  // Amethyst grown
                  if (doAm) {
                     if (b == Blocks.AMETHYST_CLUSTER) {
                        count += 2;
                        if (doGlow) glowCells += glowAround(world, wx, wy, wz, mut);
                        continue;
                     }
                     if (b == Blocks.LARGE_AMETHYST_BUD) {
                        count++;
                        continue;
                     }
                     if (b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST) {
                        // lining counts slower
                        if (((wx + wy + wz) & 15) == 0) count++;
                        if (doGlow) glowCells += glowAround(world, wx, wy, wz, mut);
                        continue;
                     }
                  }

                  // Bamboo: column top, tall
                  if (doBamboo && (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING)) {
                     mut.set(wx, wy + 1, wz);
                     BlockState above = world.getBlockState(mut);
                     if (above.isOf(Blocks.BAMBOO) || above.isOf(Blocks.BAMBOO_SAPLING)) continue;
                     if (columnLen(world, wx, wy, wz, Direction.DOWN, Blocks.BAMBOO, Blocks.BAMBOO_SAPLING) >= 10) {
                        count++;
                     }
                     continue;
                  }

                  // Bee nest / hive
                  if (doBee && (b == Blocks.BEE_NEST || b == Blocks.BEEHIVE)) {
                     count += 2;
                     continue;
                  }

                  // Rotated deepslate (horizontal axis — common player-placed signal)
                  if (doRot && isRotatedDeepslate(st)) {
                     count++;
                  }
               }
            }
         }
      }

      if (doGlow && glowCells > 0) {
         count += glowCells / 12; // New Gen heat style bonus
      }
      return count;
   }

   private static int glowAround(World world, int x, int y, int z, BlockPos.Mutable mut) {
      int n = 0;
      for (Direction d : Direction.values()) {
         mut.set(x + d.getOffsetX(), y + d.getOffsetY(), z + d.getOffsetZ());
         if (!world.isChunkLoaded(mut)) continue;
         if (!world.getBlockState(mut).isAir()) continue;
         int light = world.getLightLevel(LightType.BLOCK, mut);
         if (light >= 1 && light <= 10) n++;
      }
      return n;
   }

   private static int columnLen(World world, int x, int y, int z, Direction dir, Block... match) {
      BlockPos.Mutable mut = new BlockPos.Mutable(x, y, z);
      int n = 0;
      for (int i = 0; i < 32; i++) {
         BlockState st = world.getBlockState(mut);
         boolean ok = false;
         for (Block b : match) {
            if (st.isOf(b)) { ok = true; break; }
         }
         if (!ok) break;
         n++;
         mut.move(dir);
      }
      return n;
   }

   private static boolean isRotatedDeepslate(BlockState st) {
      Block b = st.getBlock();
      if (b != Blocks.DEEPSLATE && b != Blocks.COBBLED_DEEPSLATE
            && b != Blocks.POLISHED_DEEPSLATE && b != Blocks.DEEPSLATE_BRICKS
            && b != Blocks.DEEPSLATE_TILES) {
         // also plain deepslate pillar
         if (b != Blocks.DEEPSLATE) return false;
      }
      if (st.contains(Properties.AXIS)) {
         Direction.Axis axis = st.get(Properties.AXIS);
         return axis != Direction.Axis.Y; // horizontal = often player rotated
      }
      if (st.contains(PillarBlock.AXIS)) {
         return st.get(PillarBlock.AXIS) != Direction.Axis.Y;
      }
      return false;
   }

   private static boolean isInteresting(
         BlockState st,
         boolean doKelp, boolean doCave, boolean doVines, boolean doAm,
         boolean doBamboo, boolean doBee, boolean doRot
   ) {
      Block b = st.getBlock();
      if (doKelp && (b == Blocks.KELP || b == Blocks.KELP_PLANT)) return true;
      if (doCave && (b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT)) return true;
      if (doVines && b == Blocks.VINE) return true;
      if (doAm && (b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST
            || b == Blocks.AMETHYST_CLUSTER
            || b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.SMALL_AMETHYST_BUD)) {
         return true;
      }
      if (doBamboo && (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING)) return true;
      if (doBee && (b == Blocks.BEE_NEST || b == Blocks.BEEHIVE)) return true;
      if (doRot && isRotatedDeepslate(st)) return true;
      return false;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Map<ChunkPos, Integer> map = this.hits;
      if (map.isEmpty() || mc.world == null || mc.player == null) return;
      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 100));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : map.keySet()) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16, y2, z1 + 16, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      KryptonSusFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showPercent.getValue()) return;
      Map<ChunkPos, Integer> map = self.hits;
      if (map.isEmpty()) {
         self.labelCache.clear();
         return;
      }
      int sens = Math.max(1, self.sensitivity.getValue());
      double textY = self.renderY.getValue() + 1.8;
      long now = System.currentTimeMillis();
      Set<ChunkPos> keep = new HashSet<>();

      for (Map.Entry<ChunkPos, Integer> e : map.entrySet()) {
         ChunkPos cp = e.getKey();
         keep.add(cp);
         int grown = e.getValue();
         float t = (grown - sens) / (float) Math.max(1, sens * 2);
         if (t < 0f) t = 0f;
         if (t > 1f) t = 1f;
         int percent = Math.round((0.55f + 0.45f * t) * 100f);

         LabelPos lp = self.labelCache.computeIfAbsent(cp, k -> new LabelPos());
         lp.percent = percent;
         double wx = (cp.x << 4) + 8.0;
         double wz = (cp.z << 4) + 8.0;
         boolean ok = Render3D.projectToPoint(
            Render3D.modelViewMatrix, Render3D.projectionMatrix, wx, textY, wz, self.projected);
         if (ok && self.projected.visible) {
            lp.x = (float) self.projected.x;
            lp.y = (float) self.projected.y;
            lp.lastOkMs = now;
         }
         if (now - lp.lastOkMs < 500L && lp.lastOkMs > 0) {
            String tag = "KR";
            String pct = lp.percent + "%";
            int tw = FontRenderer.INSTANCE.getWidth(tag);
            int pw = FontRenderer.INSTANCE.getWidth(pct);
            float tx = lp.x - tw / 2f;
            float ty = lp.y - 18f;
            FontRenderer.INSTANCE.drawString(context, tag, tx + 1, ty + 1, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, tag, tx, ty, 0xFFCC66FF);
            FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f + 1, ty + 11, 0xFF000000);
            FontRenderer.INSTANCE.drawString(context, pct, lp.x - pw / 2f, ty + 10, 0xFFE8CCFF);
         }
      }
      self.labelCache.keySet().removeIf(c -> !keep.contains(c));
   }
}
