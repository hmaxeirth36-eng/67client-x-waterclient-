package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Sus Chunk Finder — logic inspired by 67Client:
 * Signal weights: AMETHYST 6 (cap 16), KELP/BAMBOO/BERRIES/VINES 2 (cap 6), DRIPSTONE 2 (cap 5)
 * Threshold = sensitivity * POINTS_PER_SENSITIVITY (5)
 * Amethyst: block count + block-light level 5 cells (Donut hidden geode signal)
 */
public final class SUSChunkFinder extends Module {
   public static SUSChunkFinder INSTANCE;
   public static final int POINTS_PER_SENSITIVITY = 5;

   public final Setting<Integer> simulationDist = new Setting<>("Simulation Dist", 5, 1, 12);
   public final Setting<Integer> sensitivity = new Setting<>("Sensitivity", 3, 1, 15);
   public final Setting<Boolean> smartMode = new Setting<>("Smart Mode", true);
   public final Setting<Integer> scanSpeed = new Setting<>("Scan Speed", 10, 2, 24);
   public final Setting<Integer> renderY = new Setting<>("Render Y", 64, -64, 320);
   public final Setting<Integer> fillOpacity = new Setting<>("Fill Opacity", 55, 0, 255);
   public final Setting<Boolean> outline = new Setting<>("Outline", true);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(255, 50, 50, 55));

   public final Setting<Boolean> amethyst = new Setting<>("Amethyst", true);
   public final Setting<Boolean> kelp = new Setting<>("Kelp", true);
   public final Setting<Boolean> bamboo = new Setting<>("Bamboo", true);
   public final Setting<Boolean> berries = new Setting<>("Berries", true);
   public final Setting<Boolean> vines = new Setting<>("Vines", true);
   public final Setting<Boolean> dripstone = new Setting<>("Dripstone", true);
   public final Setting<Boolean> light5 = new Setting<>("Light-5 Amethyst", true);

   public volatile Set<ChunkPos> hits = Collections.emptySet();

   private ExecutorService scanExec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tickCount = 0;
   private int scanCursor = 0;

   public SUSChunkFinder() {
      super("67 Sus Chunk Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.simulationDist);
      this.addSetting(this.sensitivity);
      this.addSetting(this.smartMode);
      this.addSetting(this.scanSpeed);
      this.addSetting(this.renderY);
      this.addSetting(this.fillOpacity);
      this.addSetting(this.outline);
      this.addSetting(this.fillColor);
      this.addSetting(this.amethyst);
      this.addSetting(this.kelp);
      this.addSetting(this.bamboo);
      this.addSetting(this.berries);
      this.addSetting(this.vines);
      this.addSetting(this.dripstone);
      this.addSetting(this.light5);
   }

   @Override
   public void onEnable() {
      this.hits = Collections.emptySet();
      this.tickCount = 0;
      this.scanCursor = 0;
   }

   @Override
   public void onDisable() {
      this.hits = Collections.emptySet();
      this.scanning.set(false);
      if (this.scanExec != null) {
         this.scanExec.shutdownNow();
         this.scanExec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tickCount % 3 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.scanExec == null || this.scanExec.isShutdown()) {
         this.scanExec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "water-x67-sus");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.simulationDist.getValue();
      final double threshold = this.sensitivity.getValue() * (double) POINTS_PER_SENSITIVITY;
      final boolean smart = this.smartMode.getValue();
      final int batch = this.scanSpeed.getValue();

      final boolean doAm = this.amethyst.getValue();
      final boolean doKelp = this.kelp.getValue();
      final boolean doBamboo = this.bamboo.getValue();
      final boolean doBerries = this.berries.getValue();
      final boolean doVines = this.vines.getValue();
      final boolean doDrip = this.dripstone.getValue();
      final boolean doLight5 = this.light5.getValue();

      final List<ChunkPos> positions = new ArrayList<>();
      final List<WorldChunk> chunks = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }
      if (positions.isEmpty()) {
         this.scanning.set(false);
         return;
      }

      final int start = this.scanCursor % positions.size();
      this.scanCursor = start + batch;
      final Set<ChunkPos> retained = new HashSet<>();
      for (ChunkPos cp : this.hits) {
         if (Math.abs(cp.x - origin.x) <= radius && Math.abs(cp.z - origin.z) <= radius) {
            retained.add(cp);
         }
      }

      // Light sampling must touch world on client thread — do light5 on main, rest async
      final Map<ChunkPos, Integer> light5Counts = new HashMap<>();
      if (doLight5 && doAm) {
         BlockPos.Mutable mut = new BlockPos.Mutable();
         int endL = Math.min(positions.size(), start + batch);
         for (int i = start; i < endL; i++) {
            ChunkPos cp = positions.get(i);
            int c = countLight5(cp, mut);
            if (c > 0) light5Counts.put(cp, c);
         }
         if (start + batch > positions.size()) {
            for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
               ChunkPos cp = positions.get(i);
               int c = countLight5(cp, mut);
               if (c > 0) light5Counts.put(cp, c);
            }
         }
      }

      this.scanExec.submit(() -> {
         try {
            Set<ChunkPos> next = new HashSet<>(retained);
            List<Integer> idxs = new ArrayList<>();
            int end = Math.min(positions.size(), start + batch);
            for (int i = start; i < end; i++) idxs.add(i);
            if (start + batch > positions.size()) {
               for (int i = 0; i < Math.min(batch - (positions.size() - start), positions.size()); i++) {
                  idxs.add(i);
               }
            }

            for (int idx : idxs) {
               if (idx < 0 || idx >= positions.size()) continue;
               ChunkPos cp = positions.get(idx);
               WorldChunk wc = chunks.get(idx);
               double score = scoreChunk(wc, doAm, doKelp, doBamboo, doBerries, doVines, doDrip);
               int l5 = light5Counts.getOrDefault(cp, 0);
               if (doLight5 && doAm && l5 > 0) {
                  // same weight as amethyst blocks, capped
                  score += Math.min(l5, 16) * 6.0;
               }

               double need = threshold;
               if (smart) {
                  int sec = 0;
                  for (ChunkSection s : wc.getSectionArray()) {
                     if (s != null && !s.isEmpty()) sec++;
                  }
                  if (sec < 8) need *= 0.85;
                  if (sec < 4) need *= 0.75;
               }

               if (score >= need) next.add(cp);
               else next.remove(cp);
            }
            this.hits = Collections.unmodifiableSet(next);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   /** Sample block light == 5 in geode Y band (67Client-style hidden amethyst signal). */
   private int countLight5(ChunkPos cp, BlockPos.Mutable mut) {
      if (mc.world == null) return 0;
      int count = 0;
      int x0 = cp.getStartX();
      int z0 = cp.getStartZ();
      // sample every 2 blocks for speed, Y -48..48 geode band
      for (int y = -48; y <= 48; y += 2) {
         for (int x = 0; x < 16; x += 2) {
            for (int z = 0; z < 16; z += 2) {
               mut.set(x0 + x, y, z0 + z);
               if (mc.world.getLightLevel(LightType.BLOCK, mut) == 5) {
                  count++;
               }
            }
         }
      }
      return count;
   }

   private static double scoreChunk(
         WorldChunk chunk,
         boolean doAm, boolean doKelp, boolean doBamboo, boolean doBerries, boolean doVines, boolean doDrip
   ) {
      int am = 0, kelpN = 0, bambooN = 0, berryN = 0, vineN = 0, dripN = 0;

      for (ChunkSection section : chunk.getSectionArray()) {
         if (section == null || section.isEmpty()) continue;
         if (!section.hasAny(SUSChunkFinder::isTracked)) continue;

         for (int x = 0; x < 16; x++) {
            for (int y = 0; y < 16; y++) {
               for (int z = 0; z < 16; z++) {
                  BlockState st = section.getBlockState(x, y, z);
                  Block b = st.getBlock();
                  if (doAm && isAmethyst(st)) am++;
                  else if (doKelp && (b == Blocks.KELP || b == Blocks.KELP_PLANT)) kelpN++;
                  else if (doBamboo && (b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING)) bambooN++;
                  else if (doBerries && b == Blocks.SWEET_BERRY_BUSH) {
                     // prefer max growth if property exists
                     if (st.contains(SweetBerryBushBlock.AGE) && st.get(SweetBerryBushBlock.AGE) >= 3) berryN += 2;
                     else berryN++;
                  } else if (doVines && (b == Blocks.VINE || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT)) vineN++;
                  else if (doDrip && (b == Blocks.POINTED_DRIPSTONE || b == Blocks.DRIPSTONE_BLOCK)) dripN++;
               }
            }
         }
      }

      // 67Client weights + caps
      double score = 0;
      if (doAm) score += Math.min(am, 16) * 6.0;
      if (doKelp) score += Math.min(kelpN, 6) * 2.0;
      if (doBamboo) score += Math.min(bambooN, 6) * 2.0;
      if (doBerries) score += Math.min(berryN, 6) * 2.0;
      if (doVines) score += Math.min(vineN, 6) * 2.0;
      if (doDrip) score += Math.min(dripN, 5) * 2.0;
      return score;
   }

   private static boolean isTracked(BlockState st) {
      Block b = st.getBlock();
      return isAmethyst(st)
         || b == Blocks.KELP || b == Blocks.KELP_PLANT
         || b == Blocks.BAMBOO || b == Blocks.BAMBOO_SAPLING
         || b == Blocks.SWEET_BERRY_BUSH
         || b == Blocks.VINE || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT
         || b == Blocks.POINTED_DRIPSTONE || b == Blocks.DRIPSTONE_BLOCK;
   }

   private static boolean isAmethyst(BlockState st) {
      Block b = st.getBlock();
      return b == Blocks.AMETHYST_BLOCK || b == Blocks.BUDDING_AMETHYST
         || b == Blocks.AMETHYST_CLUSTER
         || b == Blocks.SMALL_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.LARGE_AMETHYST_BUD;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      Set<ChunkPos> set = this.hits;
      if (set.isEmpty() || mc.world == null || mc.player == null) return;

      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);

      double y = this.renderY.getValue() - cam.y;
      double y2 = y + 0.25;
      Color base = this.fillColor.getValue();
      int a = this.fillOpacity.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), a);
      Color out = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, a + 120));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      GL11.glEnable(GL11.GL_BLEND);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : set) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16.0, y2, z1 + 16.0, fill);
         if (this.outline.getValue()) {
            batch.renderOutlineBox(x1, y, z1, x1 + 16.0, y2, z1 + 16.0, out);
         }
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      // no % labels
   }
}
