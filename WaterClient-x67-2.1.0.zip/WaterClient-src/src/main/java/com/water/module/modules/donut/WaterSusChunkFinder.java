package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/** Original Water-style Sus: amethyst density + underground storage/spawner signature. */
public final class WaterSusChunkFinder extends Module {
   public static WaterSusChunkFinder INSTANCE;

   public final Setting<Integer> scanRadius = new Setting<>("Scan Radius", 2, 1, 8);
   public final Setting<Integer> minAmethyst = new Setting<>("Min Amethyst", 8, 1, 64);
   public final Setting<Integer> baseThreshold = new Setting<>("Base Threshold", 8, 1, 40);
   public final Setting<Integer> displayY = new Setting<>("Display Y", 64, -64, 320);
   public final Setting<Integer> alpha = new Setting<>("Alpha", 50, 0, 255);
   public final Setting<Color> amColor = new Setting<>("Amethyst Color", new Color(180, 80, 255, 50));
   public final Setting<Color> baseColor = new Setting<>("Base Color", new Color(255, 60, 60, 50));
   public final Setting<Boolean> detectAmethyst = new Setting<>("Amethyst", true);
   public final Setting<Boolean> detectBase = new Setting<>("Base Storage", true);

   public volatile Set<ChunkPos> amHits = Collections.emptySet();
   public volatile Set<ChunkPos> baseHits = Collections.emptySet();

   private ExecutorService exec;
   private final AtomicBoolean scanning = new AtomicBoolean(false);
   private int tick;

   public WaterSusChunkFinder() {
      super("Sus Chunk Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.scanRadius);
      this.addSetting(this.minAmethyst);
      this.addSetting(this.baseThreshold);
      this.addSetting(this.displayY);
      this.addSetting(this.alpha);
      this.addSetting(this.amColor);
      this.addSetting(this.baseColor);
      this.addSetting(this.detectAmethyst);
      this.addSetting(this.detectBase);
   }

   @Override
   public void onEnable() {
      this.amHits = Collections.emptySet();
      this.baseHits = Collections.emptySet();
   }

   @Override
   public void onDisable() {
      this.amHits = Collections.emptySet();
      this.baseHits = Collections.emptySet();
      this.scanning.set(false);
      if (this.exec != null) {
         this.exec.shutdownNow();
         this.exec = null;
      }
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;
      if (++this.tick % 5 != 0) return;
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.exec == null || this.exec.isShutdown()) {
         this.exec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "water-sus");
            t.setDaemon(true);
            return t;
         });
      }

      final ChunkPos origin = mc.player.getChunkPos();
      final int radius = this.scanRadius.getValue() * 3;
      final int minAm = this.minAmethyst.getValue();
      final int baseTh = this.baseThreshold.getValue();
      final boolean doAm = this.detectAmethyst.getValue();
      final boolean doBase = this.detectBase.getValue();

      List<ChunkPos> pos = new ArrayList<>();
      List<WorldChunk> ch = new ArrayList<>();
      for (int dx = -radius; dx <= radius; dx++) {
         for (int dz = -radius; dz <= radius; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               pos.add(cp);
               ch.add(wc);
            }
         }
      }

      this.exec.submit(() -> {
         try {
            Set<ChunkPos> am = new HashSet<>();
            Set<ChunkPos> base = new HashSet<>();
            for (int i = 0; i < pos.size(); i++) {
               ChunkPos cp = pos.get(i);
               WorldChunk wc = ch.get(i);
               if (doAm && countAmethyst(wc) >= minAm) am.add(cp);
               if (doBase && hasBase(wc, baseTh)) base.add(cp);
            }
            this.amHits = Collections.unmodifiableSet(am);
            this.baseHits = Collections.unmodifiableSet(base);
         } catch (Throwable ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   private static int countAmethyst(WorldChunk chunk) {
      int n = 0;
      int bottom = chunk.getBottomY();
      ChunkSection[] sections = chunk.getSectionArray();
      for (int s = 0; s < sections.length; s++) {
         int sectionY = bottom + s * 16;
         if (sectionY > 32) break;
         ChunkSection sec = sections[s];
         if (sec == null || sec.isEmpty()) continue;
         if (!sec.hasAny(st -> st.isOf(Blocks.AMETHYST_BLOCK) || st.isOf(Blocks.AMETHYST_CLUSTER)
               || st.isOf(Blocks.BUDDING_AMETHYST))) continue;
         for (int x = 0; x < 16; x++)
            for (int y = 0; y < 16; y++)
               for (int z = 0; z < 16; z++) {
                  BlockState st = sec.getBlockState(x, y, z);
                  if (st.isOf(Blocks.AMETHYST_BLOCK) || st.isOf(Blocks.AMETHYST_CLUSTER)
                        || st.isOf(Blocks.BUDDING_AMETHYST)
                        || st.isOf(Blocks.SMALL_AMETHYST_BUD)
                        || st.isOf(Blocks.MEDIUM_AMETHYST_BUD)
                        || st.isOf(Blocks.LARGE_AMETHYST_BUD)) n++;
               }
      }
      return n;
   }

   private static boolean hasBase(WorldChunk chunk, int threshold) {
      int storage = 0;
      boolean spawner = false;
      int bottom = chunk.getBottomY();
      ChunkSection[] sections = chunk.getSectionArray();
      for (int s = 0; s < sections.length; s++) {
         int sectionY = bottom + s * 16;
         if (sectionY >= 0) break;
         ChunkSection sec = sections[s];
         if (sec == null || sec.isEmpty()) continue;
         int maxY = Math.min(15, -sectionY - 1);
         for (int x = 0; x < 16; x++)
            for (int z = 0; z < 16; z++)
               for (int y = 0; y <= maxY; y++) {
                  BlockState st = sec.getBlockState(x, y, z);
                  if (st.isOf(Blocks.SPAWNER)) spawner = true;
                  if (st.isOf(Blocks.CHEST) || st.isOf(Blocks.TRAPPED_CHEST)
                        || st.isOf(Blocks.BARREL) || st.isOf(Blocks.HOPPER)
                        || st.getBlock() instanceof ShulkerBoxBlock) storage++;
               }
      }
      return spawner || storage >= threshold;
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world == null || mc.player == null) return;
      Set<ChunkPos> am = this.amHits;
      Set<ChunkPos> base = this.baseHits;
      if (am.isEmpty() && base.isEmpty()) return;

      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);
      double y = this.displayY.getValue() - cam.y;
      double y2 = y + 0.2;
      int a = this.alpha.getValue();
      Color ac = this.amColor.getValue();
      Color bc = this.baseColor.getValue();
      Color amFill = new Color(ac.getRed(), ac.getGreen(), ac.getBlue(), a);
      Color baseFill = new Color(bc.getRed(), bc.getGreen(), bc.getBlue(), a);

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);
      for (ChunkPos cp : am) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, amFill);
      }
      for (ChunkPos cp : base) {
         if (am.contains(cp)) continue;
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, y, z1, x1 + 16, y2, z1 + 16, baseFill);
      }
      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {}
}
